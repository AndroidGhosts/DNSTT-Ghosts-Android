module github.com/AndroidGhosts/dnstt-ghosts/core

go 1.26.0

require (
	github.com/refraction-networking/utls v1.6.6
	github.com/xjasonlyu/tun2socks/v2 v2.6.0
	github.com/xtaci/kcp-go/v5 v5.6.8
	github.com/xtaci/smux v1.5.24
	golang.org/x/crypto v0.58.0
	golang.org/x/net v0.61.0
	gvisor.dev/gvisor v0.0.0-20250523182742-eede7a881b20
	www.bamsoftware.com/git/dnstt.git v0.0.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/cloudflare/circl v1.3.7 // indirect
	github.com/flynn/noise v1.0.0 // indirect
	github.com/google/btree v1.1.3 // indirect
	github.com/klauspost/compress v1.17.4 // indirect
	github.com/klauspost/cpuid/v2 v2.2.6 // indirect
	github.com/klauspost/reedsolomon v1.12.0 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/templexxx/cpu v0.1.0 // indirect
	github.com/templexxx/xorsimd v0.4.2 // indirect
	github.com/tjfoc/gmsm v1.4.1 // indirect
	golang.org/x/mobile v0.0.0-20261011034528-197770444867 // indirect
	golang.org/x/mod v0.42.0 // indirect
	golang.org/x/sync v0.24.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/text v0.43.0 // indirect
	golang.org/x/time v0.11.0 // indirect
	golang.org/x/tools v0.52.0 // indirect
)

replace www.bamsoftware.com/git/dnstt.git => ./third_party/dnstt

