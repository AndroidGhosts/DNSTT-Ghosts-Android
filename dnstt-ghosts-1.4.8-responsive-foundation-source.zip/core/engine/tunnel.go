package engine

import (
	"fmt"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/xtaci/kcp-go/v5"
	"github.com/xtaci/smux"
	"golang.org/x/crypto/ssh"

	"github.com/AndroidGhosts/dnstt-ghosts/core/internal/client"
	"www.bamsoftware.com/git/dnstt.git/dns"
	"www.bamsoftware.com/git/dnstt.git/noise"
	"www.bamsoftware.com/git/dnstt.git/turbotunnel"
)

// stack is one complete DNS transport + KCP + Noise + smux session.
type tstack struct {
	pconn net.PacketConn
	kcp   *kcp.UDPSession
	sess  *smux.Session
}

func (s *tstack) close() {
	if s == nil {
		return
	}
	if s.sess != nil {
		s.sess.Close()
	}
	if s.kcp != nil {
		s.kcp.Close()
	}
	if s.pconn != nil {
		s.pconn.Close()
	}
}

// Tunnel manages the dnstt session and dials connections through it.
type Tunnel struct {
	cfg    *Config
	Stats  *Stats
	domain dns.Name
	pubkey []byte
	mtu    int
	label  string

	mu  sync.Mutex
	cur *tstack

	sshMu  sync.Mutex
	sshCli *ssh.Client

	listeners []net.Listener
	closed    chan struct{}
	closeOnce sync.Once

	statusMu sync.Mutex
	status   string
}

func (t *Tunnel) StatsRef() *Stats        { return t.Stats }
func (t *Tunnel) RemoteDNS() string       { return t.cfg.RemoteDNS }
func (t *Tunnel) DNSCacheEnabled() bool   { return t.cfg.DNSCache }
func (t *Tunnel) DNSCacheTTLSeconds() int { return t.cfg.DNSCacheTTLSeconds }
func (t *Tunnel) DNSCacheMaxEntries() int { return t.cfg.DNSCacheMaxEntries }
func (t *Tunnel) IPv6Blocked() bool       { return t.cfg.BlockIPv6 }

// MaxPayload returns the maximum per-query payload for a domain.
func MaxPayload(domain dns.Name) int {
	capacity := 255 - 1
	for _, label := range domain {
		capacity -= len(label) + 1
	}
	capacity = capacity * 63 / 64
	capacity = capacity * 5 / 8
	return capacity - 8 - 1 - client.NumPadding - 1
}

// NewTunnel validates the config and prepares a tunnel (no network yet).
func NewTunnel(cfg *Config) (*Tunnel, error) {
	domain, err := dns.ParseName(cfg.Domain)
	if err != nil {
		return nil, fmt.Errorf("invalid domain %q: %v", cfg.Domain, err)
	}
	pubkey, err := noise.DecodeKey(cfg.Pubkey)
	if err != nil {
		return nil, fmt.Errorf("pubkey format error: %v", err)
	}
	mtu := MaxPayload(domain)
	if cfg.SegmentSize > 0 && cfg.SegmentSize < mtu {
		mtu = cfg.SegmentSize
	}
	if mtu < 40 {
		return nil, fmt.Errorf("domain %s leaves only %d bytes per segment", domain, mtu)
	}
	label := "none"
	if cfg.Transport != "udp" {
		label, err = client.SampleUTLS(cfg.UTLS)
		if err != nil {
			return nil, err
		}
	}
	client.SetFragment(client.FragmentConfig{
		Enabled: cfg.Fragment.Enabled && (cfg.Transport == "doh" || cfg.Transport == "dot"),
		MinSize: cfg.Fragment.MinSize,
		MaxSize: cfg.Fragment.MaxSize,
		Delay:   time.Duration(cfg.Fragment.DelayMs) * time.Millisecond,
		Packets: cfg.Fragment.Packets,
	})
	client.SetPollDelays(time.Duration(cfg.PollMinMs)*time.Millisecond, time.Duration(cfg.PollMaxMs)*time.Millisecond)
	t := &Tunnel{
		cfg: cfg, Stats: &Stats{}, domain: domain, pubkey: pubkey,
		mtu: mtu, label: label, closed: make(chan struct{}),
	}
	atomic.StoreInt64(&t.Stats.MTU, int64(mtu))
	atomic.StoreInt64(&t.Stats.TunnelCount, 1)
	t.setStatus("idle")
	return t, nil
}

func (t *Tunnel) setStatus(s string) {
	t.statusMu.Lock()
	t.status = s
	t.statusMu.Unlock()
}

// Status returns a short human-readable state.
func (t *Tunnel) Status() string {
	t.statusMu.Lock()
	defer t.statusMu.Unlock()
	return t.status
}

func (t *Tunnel) buildTransport() (net.PacketConn, error) {
	var conns []net.PacketConn
	var addrs []net.Addr
	for _, r := range t.cfg.Resolvers {
		transports := []string{t.cfg.Transport}
		for _, transport := range transports {
			var c net.PacketConn
			var addr net.Addr = turbotunnel.DummyAddr{}
			var err error
			switch transport {
			case "doh":
				c, err = client.NewDoH(r, t.label, t.cfg.DohSenders)
			case "dot":
				c, err = client.NewDoT(r, t.label)
			default:
				var ua *net.UDPAddr
				ua, err = net.ResolveUDPAddr("udp", r)
				if err == nil {
					addr = ua
					c, err = net.ListenUDP("udp", nil)
				}
			}
			if err != nil {
				log.Printf("resolver %s/%s unavailable: %v", r, transport, err)
				continue
			}
			log.Printf("resolver ready: %s via %s", r, transport)
			conns = append(conns, c)
			addrs = append(addrs, addr)
		}
	}
	if len(conns) == 0 {
		return nil, fmt.Errorf("no usable resolver")
	}
	return newMultiPacketConn(conns, addrs, t.cfg.ResolverStrategy, t.Stats), nil
}

func (t *Tunnel) buildStack() (*tstack, error) {
	transport, err := t.buildTransport()
	if err != nil {
		return nil, err
	}
	st := &tstack{}
	st.pconn = client.NewDNS(transport, turbotunnel.DummyAddr{}, t.domain)
	conn, err := kcp.NewConn2(turbotunnel.DummyAddr{}, nil, 0, 0, st.pconn)
	if err != nil {
		st.close()
		return nil, fmt.Errorf("opening KCP conn: %v", err)
	}
	st.kcp = conn
	conn.SetStreamMode(true)
	if t.cfg.KcpNoDelay {
		interval := t.cfg.KcpIntervalMs
		if interval <= 0 {
			interval = 20
		}
		resend := t.cfg.KcpResend
		if resend < 0 {
			resend = 0
		}
		conn.SetNoDelay(1, interval, resend, 1)
	} else {
		conn.SetNoDelay(0, 0, 0, 1)
	}
	window := t.cfg.KcpWindow
	if window <= 0 {
		window = turbotunnel.QueueSize / 2
	}
	conn.SetWindowSize(window, window)
	if !conn.SetMtu(t.mtu) {
		st.close()
		return nil, fmt.Errorf("invalid segment size %d", t.mtu)
	}
	log.Printf("session %08x: segment size %d bytes, resolvers %d (%s, %s)", conn.GetConv(), t.mtu, len(t.cfg.Resolvers), t.cfg.Transport, t.label)

	conn.SetDeadline(time.Now().Add(45 * time.Second))
	rw, err := noise.NewClient(conn, t.pubkey)
	if err != nil {
		st.close()
		return nil, fmt.Errorf("noise handshake: %v", err)
	}
	log.Printf("authentication verified: Noise public-key handshake succeeded")
	conn.SetDeadline(time.Time{})

	sc := smux.DefaultConfig()
	sc.Version = 2
	sc.KeepAliveInterval = time.Duration(t.cfg.KeepAliveSec) * time.Second
	sc.KeepAliveTimeout = time.Duration(t.cfg.IdleTimeoutSec) * time.Second
	if sc.KeepAliveTimeout <= sc.KeepAliveInterval {
		sc.KeepAliveTimeout = sc.KeepAliveInterval * 3
	}
	sc.MaxStreamBuffer = t.cfg.PayloadClientBufferKB * 1024
	sc.MaxReceiveBuffer = t.cfg.PayloadRemoteBufferKB * 1024
	if sc.MaxReceiveBuffer < sc.MaxStreamBuffer {
		sc.MaxReceiveBuffer = sc.MaxStreamBuffer * 2
	}
	sess, err := smux.Client(rw, sc)
	if err != nil {
		st.close()
		return nil, fmt.Errorf("opening smux session: %v", err)
	}
	st.sess = sess
	atomic.AddInt64(&t.Stats.Sessions, 1)
	return st, nil
}

// session returns a live smux session, rebuilding the whole stack if needed.
func (t *Tunnel) session() (*smux.Session, error) {
	t.mu.Lock()
	select {
	case <-t.closed:
		t.mu.Unlock()
		return nil, net.ErrClosed
	default:
	}
	if t.cur != nil && !t.cur.sess.IsClosed() {
		sess := t.cur.sess
		t.mu.Unlock()
		return sess, nil
	}
	if t.cur != nil {
		log.Printf("session lost, reconnecting")
		t.cur.close()
		t.cur = nil
	}
	t.setStatus("connecting")
	t.mu.Unlock()
	st, err := t.buildStack()
	if err != nil {
		t.setStatus("error: " + err.Error())
		return nil, err
	}
	t.mu.Lock()
	select {
	case <-t.closed:
		t.mu.Unlock()
		st.close()
		return nil, net.ErrClosed
	default:
	}
	if t.cur != nil && !t.cur.sess.IsClosed() {
		sess := t.cur.sess
		t.mu.Unlock()
		st.close()
		return sess, nil
	}
	t.cur = st
	t.mu.Unlock()
	t.setStatus("connected")
	log.Printf("tunnel connected")
	return st.sess, nil
}

// OpenStream opens a raw stream to the server's forward target.
func (t *Tunnel) OpenStream() (net.Conn, error) {
	var lastErr error
	for i := 0; i < 2; i++ {
		sess, err := t.session()
		if err != nil {
			return nil, err
		}
		s, err := sess.OpenStream()
		if err == nil {
			return s, nil
		}
		lastErr = err
		sess.Close()
	}
	return nil, lastErr
}

// Dial connects to addr (host:port) through the tunnel according to Mode.
func (t *Tunnel) Dial(addr string) (net.Conn, error) {
	var c net.Conn
	var err error
	switch t.cfg.Mode {
	case "ssh":
		c, err = t.sshDial(addr)
	case "forward":
		c, err = t.OpenStream()
	default:
		c, err = t.OpenStream()
		if err == nil {
			c.SetDeadline(time.Now().Add(30 * time.Second))
			err = socks5Connect(c, addr, t.cfg.SocksUser, t.cfg.SocksPass, t.cfg.SocksFast)
			if err != nil {
				c.Close()
			} else {
				c.SetDeadline(time.Time{})
			}
		}
	}
	if err != nil {
		return nil, err
	}
	return &countConn{Conn: c, s: t.Stats}, nil
}

// Connect eagerly establishes the session and keeps it alive.
func (t *Tunnel) Connect() {
	t.Stats.markStart()
	go func() {
		backoff := time.Duration(t.cfg.ReconnectSec) * time.Second
		for {
			_, err := t.session()
			if err == nil && t.cfg.Mode == "ssh" {
				_, err = t.ssh()
			}
			if err != nil {
				log.Printf("connect: %v (retry in %v)", err, backoff)
			}
			select {
			case <-t.closed:
				return
			case <-time.After(backoff):
			}
		}
	}()
}

// Close tears everything down.
func (t *Tunnel) Close() {
	t.closeOnce.Do(func() {
		close(t.closed)
		for _, l := range t.listeners {
			l.Close()
		}
		t.sshMu.Lock()
		if t.sshCli != nil {
			t.sshCli.Close()
		}
		t.sshMu.Unlock()
		t.mu.Lock()
		if t.cur != nil {
			t.cur.close()
			t.cur = nil
		}
		t.mu.Unlock()
		t.setStatus("stopped")
	})
}
