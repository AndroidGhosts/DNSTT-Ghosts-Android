package engine

import "testing"

const minimalTestConfig = `{"domain":"t.example.com","pubkey":"test-key","transport":"udp","resolvers":["1.1.1.1"],"mode":"socks"}`

func TestParseConfigDefaultsDNSCacheControls(t *testing.T) {
	cfg, err := ParseConfig(minimalTestConfig)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.DNSCacheTTLSeconds != 120 {
		t.Fatalf("DNS cache TTL = %d, want 120", cfg.DNSCacheTTLSeconds)
	}
	if cfg.DNSCacheMaxEntries != 2048 {
		t.Fatalf("DNS cache capacity = %d, want 2048", cfg.DNSCacheMaxEntries)
	}
}

func TestParseConfigPreservesManualDNSCacheControls(t *testing.T) {
	cfg, err := ParseConfig(`{"domain":"t.example.com","pubkey":"test-key","transport":"udp","resolvers":["1.1.1.1"],"mode":"socks","dnsCacheTtlSeconds":45,"dnsCacheMaxEntries":512,"blockIPv6":true}`)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.DNSCacheTTLSeconds != 45 || cfg.DNSCacheMaxEntries != 512 || !cfg.BlockIPv6 {
		t.Fatalf("manual controls not preserved: ttl=%d entries=%d blockIPv6=%v", cfg.DNSCacheTTLSeconds, cfg.DNSCacheMaxEntries, cfg.BlockIPv6)
	}
}

func TestParseConfigCapsDNSCacheControls(t *testing.T) {
	cfg, err := ParseConfig(`{"domain":"t.example.com","pubkey":"test-key","transport":"udp","resolvers":["1.1.1.1"],"mode":"socks","dnsCacheTtlSeconds":999999,"dnsCacheMaxEntries":999999}`)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.DNSCacheTTLSeconds != 86400 || cfg.DNSCacheMaxEntries != 65536 {
		t.Fatalf("DNS cache controls exceed safe caps: ttl=%d entries=%d", cfg.DNSCacheTTLSeconds, cfg.DNSCacheMaxEntries)
	}
}
