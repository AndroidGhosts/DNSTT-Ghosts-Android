package engine

import (
	"errors"
	"math/rand"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

type packet struct {
	b    []byte
	addr net.Addr
}

// multiPacketConn spreads DNS queries across several resolver transports.
type multiPacketConn struct {
	conns    []net.PacketConn
	addrs    []net.Addr
	strategy string
	next     uint32
	recv     chan packet
	done     chan struct{}
	once     sync.Once
	stats    *Stats
}

func newMultiPacketConn(conns []net.PacketConn, addrs []net.Addr, strategy string, stats *Stats) *multiPacketConn {
	m := &multiPacketConn{
		conns: conns, addrs: addrs, strategy: strategy,
		recv: make(chan packet, 256), done: make(chan struct{}), stats: stats,
	}
	for _, c := range conns {
		go m.readLoop(c)
	}
	return m
}

func (m *multiPacketConn) readLoop(c net.PacketConn) {
	buf := make([]byte, 65535)
	for {
		n, addr, err := c.ReadFrom(buf)
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				continue
			}
			return
		}
		atomic.AddInt64(&m.stats.QueriesRecv, 1)
		atomic.AddInt64(&m.stats.DNSBytesDown, int64(n))
		p := make([]byte, n)
		copy(p, buf[:n])
		select {
		case m.recv <- packet{p, addr}:
		case <-m.done:
			return
		}
	}
}

func (m *multiPacketConn) ReadFrom(p []byte) (int, net.Addr, error) {
	select {
	case pk := <-m.recv:
		return copy(p, pk.b), pk.addr, nil
	case <-m.done:
		return 0, nil, net.ErrClosed
	}
}

func (m *multiPacketConn) WriteTo(p []byte, _ net.Addr) (int, error) {
	atomic.AddInt64(&m.stats.QueriesSent, 1)
	atomic.AddInt64(&m.stats.DNSBytesUp, int64(len(p)))
	switch {
	case len(m.conns) == 1:
		return m.conns[0].WriteTo(p, m.addrs[0])
	case m.strategy == "parallel":
		var n int
		var err error
		for i, c := range m.conns {
			n, err = c.WriteTo(p, m.addrs[i])
		}
		return n, err
	case m.strategy == "random":
		i := rand.Intn(len(m.conns))
		return m.conns[i].WriteTo(p, m.addrs[i])
	default:
		i := int(atomic.AddUint32(&m.next, 1)) % len(m.conns)
		return m.conns[i].WriteTo(p, m.addrs[i])
	}
}

func (m *multiPacketConn) Close() error {
	m.once.Do(func() {
		close(m.done)
		for _, c := range m.conns {
			c.Close()
		}
	})
	return nil
}

func (m *multiPacketConn) LocalAddr() net.Addr                { return m.conns[0].LocalAddr() }
func (m *multiPacketConn) SetDeadline(t time.Time) error      { return nil }
func (m *multiPacketConn) SetReadDeadline(t time.Time) error  { return nil }
func (m *multiPacketConn) SetWriteDeadline(t time.Time) error { return nil }
