package engine

import (
	"encoding/binary"
	"errors"
	"io"
	"log"
	"net"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/xjasonlyu/tun2socks/v2/core"
	"github.com/xjasonlyu/tun2socks/v2/core/adapter"
	"github.com/xjasonlyu/tun2socks/v2/core/device"
	"github.com/xjasonlyu/tun2socks/v2/core/device/fdbased"
	"gvisor.dev/gvisor/pkg/tcpip/stack"
)

// Tun routes a TUN device's traffic through the tunnel.
type Tun struct {
	dev device.Device
	stk *stack.Stack
	dns *dnsForwarder
}

// Backend is the common dialer used by one tunnel or a multi-tunnel group.
type Backend interface {
	Dial(string) (net.Conn, error)
	StatsRef() *Stats
	RemoteDNS() string
	DNSCacheEnabled() bool
	DNSCacheTTLSeconds() int
	DNSCacheMaxEntries() int
	IPv6Blocked() bool
	Close()
	Status() string
}

// StartTun attaches the netstack to the given TUN file descriptor.
func StartTun(t Backend, fd int, mtu int) (*Tun, error) {
	dev, err := fdbased.Open(strconv.Itoa(fd), uint32(mtu), 0)
	if err != nil {
		return nil, err
	}
	h := &tunHandler{t: t, dns: newDNSForwarder(t), blockIPv6: t.IPv6Blocked()}
	stk, err := core.CreateStack(&core.Config{LinkEndpoint: dev, TransportHandler: h})
	if err != nil {
		dev.Close()
		return nil, err
	}
	log.Printf("VPN interface up (mtu %d), DNS via %s", mtu, t.RemoteDNS())
	return &Tun{dev: dev, stk: stk, dns: h.dns}, nil
}

func (x *Tun) Close() {
	x.stk.Close()
	x.dev.Close()
	x.dns.close()
}

type tunHandler struct {
	t         Backend
	dns       *dnsForwarder
	blockIPv6 bool
}

func (h *tunHandler) HandleTCP(c adapter.TCPConn) {
	id := c.ID()
	if h.blockIPv6 && strings.Contains(id.LocalAddress.String(), ":") {
		log.Printf("IPv6 TCP blocked by VPN policy: %s", net.JoinHostPort(id.LocalAddress.String(), strconv.Itoa(int(id.LocalPort))))
		c.Close()
		return
	}
	dst := net.JoinHostPort(id.LocalAddress.String(), strconv.Itoa(int(id.LocalPort)))
	go func() {
		up, err := h.t.Dial(dst)
		if err != nil {
			log.Printf("tcp %s: %v", dst, err)
			c.Close()
			return
		}
		relay(c, up, h.t.StatsRef())
	}()
}

func (h *tunHandler) HandleUDP(c adapter.UDPConn) {
	if h.blockIPv6 && strings.Contains(c.ID().LocalAddress.String(), ":") {
		c.Close()
		return
	}
	if c.ID().LocalPort == 53 {
		go h.dns.serve(c)
		return
	}
	c.Close()
}

type cacheEntry struct {
	resp    []byte
	expires time.Time
}

// dnsForwarder answers UDP DNS queries over DNS-over-TCP through the tunnel.
type dnsForwarder struct {
	t          Backend
	pool       chan net.Conn
	mu         sync.Mutex
	cache      map[string]cacheEntry
	ttl        time.Duration
	maxEntries int
}

func newDNSForwarder(t Backend) *dnsForwarder {
	return &dnsForwarder{
		t: t, pool: make(chan net.Conn, 4), cache: map[string]cacheEntry{},
		ttl: time.Duration(t.DNSCacheTTLSeconds()) * time.Second, maxEntries: t.DNSCacheMaxEntries(),
	}
}

func (d *dnsForwarder) close() {
	for {
		select {
		case c := <-d.pool:
			c.Close()
		default:
			return
		}
	}
}

func (d *dnsForwarder) serve(c adapter.UDPConn) {
	defer c.Close()
	buf := make([]byte, 4096)
	for {
		c.SetReadDeadline(time.Now().Add(30 * time.Second))
		n, err := c.Read(buf)
		if err != nil {
			return
		}
		q := make([]byte, n)
		copy(q, buf[:n])
		go func() {
			resp, err := d.query(q)
			if err != nil {
				if !errors.Is(err, io.EOF) && !errors.Is(err, net.ErrClosed) {
					log.Printf("DNS upstream request failed: %v", err)
				}
				return
			}
			c.Write(resp)
		}()
	}
}

func (d *dnsForwarder) query(q []byte) ([]byte, error) {
	if len(q) < 12 {
		return nil, io.ErrShortBuffer
	}
	atomic.AddInt64(&d.t.StatsRef().DNSLookups, 1)
	key := string(q[2:])
	if d.t.DNSCacheEnabled() {
		d.mu.Lock()
		e, ok := d.cache[key]
		d.mu.Unlock()
		if ok && time.Now().Before(e.expires) {
			r := append([]byte(nil), e.resp...)
			copy(r[:2], q[:2])
			return r, nil
		}
	}
	var resp []byte
	var err error
	for i := 0; i < 2; i++ {
		var c net.Conn
		select {
		case c = <-d.pool:
		default:
			c, err = d.t.Dial(d.t.RemoteDNS())
			if err != nil {
				return nil, err
			}
		}
		resp, err = exchangeTCP(c, q)
		if err == nil {
			select {
			case d.pool <- c:
			default:
				c.Close()
			}
			break
		}
		c.Close()
	}
	if err != nil {
		return nil, err
	}
	if d.t.DNSCacheEnabled() && validDNSResponse(q, resp) {
		d.storeCache(key, resp, time.Now(), responseTTL(resp))
	}
	return resp, nil
}

func (d *dnsForwarder) storeCache(key string, resp []byte, now time.Time, recordTTL time.Duration) {
	d.mu.Lock()
	defer d.mu.Unlock()
	for k, entry := range d.cache {
		if !now.Before(entry.expires) {
			delete(d.cache, k)
		}
	}
	if d.maxEntries > 0 && len(d.cache) >= d.maxEntries {
		oldestKey := ""
		var oldest time.Time
		for k, entry := range d.cache {
			if oldestKey == "" || entry.expires.Before(oldest) {
				oldestKey, oldest = k, entry.expires
			}
		}
		if oldestKey != "" {
			delete(d.cache, oldestKey)
		}
	}
	if recordTTL <= 0 || recordTTL > d.ttl {
		recordTTL = d.ttl
	}
	d.cache[key] = cacheEntry{resp: append([]byte(nil), resp...), expires: now.Add(recordTTL)}
}

func validDNSResponse(q, resp []byte) bool {
	if len(q) < 12 || len(resp) < 12 || resp[0] != q[0] || resp[1] != q[1] {
		return false
	}
	// QR must be set and TC must be clear; truncated replies must not be cached.
	return resp[2]&0x80 != 0 && resp[2]&0x02 == 0
}

func responseTTL(msg []byte) time.Duration {
	if len(msg) < 12 {
		return 0
	}
	qd := int(binary.BigEndian.Uint16(msg[4:6]))
	an := int(binary.BigEndian.Uint16(msg[6:8]))
	off := 12
	for i := 0; i < qd; i++ {
		var ok bool
		off, ok = skipDNSName(msg, off)
		if !ok || off+4 > len(msg) {
			return 0
		}
		off += 4
	}
	min := uint32(^uint32(0))
	for i := 0; i < an; i++ {
		var ok bool
		off, ok = skipDNSName(msg, off)
		if !ok || off+10 > len(msg) {
			return 0
		}
		ttl := binary.BigEndian.Uint32(msg[off+4 : off+8])
		rdlen := int(binary.BigEndian.Uint16(msg[off+8 : off+10]))
		off += 10
		if off+rdlen > len(msg) {
			return 0
		}
		if ttl < min {
			min = ttl
		}
		off += rdlen
	}
	if min == ^uint32(0) {
		return 0
	}
	return time.Duration(min) * time.Second
}

func skipDNSName(msg []byte, off int) (int, bool) {
	for off < len(msg) {
		l := int(msg[off])
		off++
		if l == 0 {
			return off, true
		}
		if l&0xc0 == 0xc0 {
			return off + 1, off < len(msg)
		}
		if l > 63 || off+l > len(msg) {
			return 0, false
		}
		off += l
	}
	return 0, false
}

func exchangeTCP(c net.Conn, q []byte) ([]byte, error) {
	c.SetDeadline(time.Now().Add(20 * time.Second))
	defer c.SetDeadline(time.Time{})
	msg := binary.BigEndian.AppendUint16(nil, uint16(len(q)))
	msg = append(msg, q...)
	if _, err := c.Write(msg); err != nil {
		return nil, err
	}
	var l [2]byte
	if _, err := io.ReadFull(c, l[:]); err != nil {
		return nil, err
	}
	resp := make([]byte, binary.BigEndian.Uint16(l[:]))
	if _, err := io.ReadFull(c, resp); err != nil {
		return nil, err
	}
	return resp, nil
}
