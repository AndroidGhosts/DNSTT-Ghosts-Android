package engine

import (
	"bufio"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// socks5Connect performs a SOCKS5 CONNECT handshake on c. With fast=true and
// no auth, the greeting and request are pipelined to save a round trip.
func socks5Connect(c net.Conn, addr, user, pass string, fast bool) error {
	host, portStr, err := net.SplitHostPort(addr)
	if err != nil {
		return err
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}
	req := []byte{5, 1, 0}
	if ip := net.ParseIP(host); ip != nil {
		if ip4 := ip.To4(); ip4 != nil {
			req = append(req, 1)
			req = append(req, ip4...)
		} else {
			req = append(req, 4)
			req = append(req, ip.To16()...)
		}
	} else {
		if len(host) > 255 {
			return errors.New("socks5: host too long")
		}
		req = append(req, 3, byte(len(host)))
		req = append(req, host...)
	}
	req = binary.BigEndian.AppendUint16(req, uint16(port))

	greet := []byte{5, 1, 0}
	if user != "" {
		greet = []byte{5, 2, 0, 2}
	}
	pipelined := fast && user == ""
	if pipelined {
		if _, err := c.Write(append(greet, req...)); err != nil {
			return err
		}
	} else if _, err := c.Write(greet); err != nil {
		return err
	}
	var b [4]byte
	if _, err := io.ReadFull(c, b[:2]); err != nil {
		return fmt.Errorf("socks5 greeting: %v", err)
	}
	if b[0] != 5 {
		return errors.New("socks5: bad server version (is the server target a SOCKS5 proxy?)")
	}
	switch b[1] {
	case 0:
	case 2:
		if user == "" {
			return errors.New("socks5: server requires username/password")
		}
		auth := []byte{1, byte(len(user))}
		auth = append(auth, user...)
		auth = append(auth, byte(len(pass)))
		auth = append(auth, pass...)
		if _, err := c.Write(auth); err != nil {
			return err
		}
		if _, err := io.ReadFull(c, b[:2]); err != nil {
			return err
		}
		if b[1] != 0 {
			return errors.New("socks5: authentication failed")
		}
	default:
		return errors.New("socks5: no acceptable auth method")
	}
	if !pipelined {
		if _, err := c.Write(req); err != nil {
			return err
		}
	}
	if _, err := io.ReadFull(c, b[:4]); err != nil {
		return fmt.Errorf("socks5 reply: %v", err)
	}
	if b[1] != 0 {
		return fmt.Errorf("socks5: connect %s failed (code %d)", addr, b[1])
	}
	var skip int
	switch b[3] {
	case 1:
		skip = 4 + 2
	case 4:
		skip = 16 + 2
	case 3:
		if _, err := io.ReadFull(c, b[:1]); err != nil {
			return err
		}
		skip = int(b[0]) + 2
	default:
		return errors.New("socks5: bad reply address type")
	}
	_, err = io.CopyN(io.Discard, c, int64(skip))
	return err
}

func (t *Tunnel) listen(addr string, serve func(net.Conn)) error {
	if addr == "" {
		return nil
	}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	t.listeners = append(t.listeners, ln)
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				var ne net.Error
				if errors.As(err, &ne) && ne.Timeout() {
					continue
				}
				return
			}
			go serve(c)
		}
	}()
	return nil
}

// StartListeners opens the local SOCKS5 / HTTP / forward listeners.
func (t *Tunnel) StartListeners() error {
	if t.cfg.Mode == "forward" {
		if err := t.listen(t.cfg.LocalForward, t.serveForward); err != nil {
			return err
		}
		log.Printf("port forward listening on %s", t.cfg.LocalForward)
		return nil
	}
	if err := t.listen(t.cfg.LocalSocks, t.serveSocks); err != nil {
		return err
	}
	log.Printf("SOCKS5 proxy listening on %s", t.cfg.LocalSocks)
	if t.cfg.LocalHTTP != "" {
		if err := t.listen(t.cfg.LocalHTTP, t.serveHTTP); err != nil {
			return err
		}
		log.Printf("HTTP proxy listening on %s", t.cfg.LocalHTTP)
	}
	return nil
}

func (t *Tunnel) serveForward(c net.Conn) {
	s, err := t.OpenStream()
	if err != nil {
		log.Printf("forward: %v", err)
		c.Close()
		return
	}
	relay(c, &countConn{Conn: s, s: t.Stats}, t.Stats)
}

func (t *Tunnel) serveSocks(c net.Conn) {
	c.SetDeadline(time.Now().Add(30 * time.Second))
	br := bufio.NewReader(c)
	fail := func(msg string) {
		log.Printf("socks: %s", msg)
		c.Close()
	}
	var hdr [2]byte
	if _, err := io.ReadFull(br, hdr[:]); err != nil || hdr[0] != 5 {
		fail("bad greeting")
		return
	}
	methods := make([]byte, hdr[1])
	if _, err := io.ReadFull(br, methods); err != nil {
		fail("bad greeting")
		return
	}
	want := byte(0)
	if t.cfg.LocalSocksUser != "" {
		want = 2
	}
	if !strings.ContainsRune(string(methods), rune(want)) {
		c.Write([]byte{5, 0xff})
		fail("no acceptable method")
		return
	}
	c.Write([]byte{5, want})
	if want == 2 {
		var v [2]byte
		io.ReadFull(br, v[:])
		u := make([]byte, v[1])
		io.ReadFull(br, u)
		var pl [1]byte
		io.ReadFull(br, pl[:])
		p := make([]byte, pl[0])
		io.ReadFull(br, p)
		if string(u) != t.cfg.LocalSocksUser || string(p) != t.cfg.LocalSocksPass {
			c.Write([]byte{1, 1})
			fail("auth failed")
			return
		}
		c.Write([]byte{1, 0})
	}
	var req [4]byte
	if _, err := io.ReadFull(br, req[:]); err != nil {
		fail("bad request")
		return
	}
	var host string
	switch req[3] {
	case 1:
		ip := make([]byte, 4)
		io.ReadFull(br, ip)
		host = net.IP(ip).String()
	case 4:
		ip := make([]byte, 16)
		io.ReadFull(br, ip)
		host = net.IP(ip).String()
	case 3:
		var l [1]byte
		io.ReadFull(br, l[:])
		h := make([]byte, l[0])
		io.ReadFull(br, h)
		host = string(h)
	default:
		fail("bad address type")
		return
	}
	var pb [2]byte
	io.ReadFull(br, pb[:])
	addr := net.JoinHostPort(host, strconv.Itoa(int(binary.BigEndian.Uint16(pb[:]))))
	if req[1] != 1 {
		c.Write([]byte{5, 7, 0, 1, 0, 0, 0, 0, 0, 0})
		fail("only CONNECT is supported")
		return
	}
	up, err := t.Dial(addr)
	if err != nil {
		c.Write([]byte{5, 5, 0, 1, 0, 0, 0, 0, 0, 0})
		fail(fmt.Sprintf("dial %s: %v", addr, err))
		return
	}
	c.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0})
	c.SetDeadline(time.Time{})
	relay(&bufConn{Conn: c, r: br}, up, t.Stats)
}

type bufConn struct {
	net.Conn
	r *bufio.Reader
}

func (b *bufConn) Read(p []byte) (int, error) { return b.r.Read(p) }

func (t *Tunnel) serveHTTP(c net.Conn) {
	br := bufio.NewReader(c)
	req, err := http.ReadRequest(br)
	if err != nil {
		c.Close()
		return
	}
	host := req.Host
	if req.Method == http.MethodConnect {
		if _, _, err := net.SplitHostPort(host); err != nil {
			host = net.JoinHostPort(host, "443")
		}
		up, err := t.Dial(host)
		if err != nil {
			c.Write([]byte("HTTP/1.1 502 Bad Gateway\r\n\r\n"))
			c.Close()
			return
		}
		c.Write([]byte("HTTP/1.1 200 Connection established\r\n\r\n"))
		relay(&bufConn{Conn: c, r: br}, up, t.Stats)
		return
	}
	if req.URL.Host != "" {
		host = req.URL.Host
	}
	if _, _, err := net.SplitHostPort(host); err != nil {
		host = net.JoinHostPort(host, "80")
	}
	up, err := t.Dial(host)
	if err != nil {
		c.Write([]byte("HTTP/1.1 502 Bad Gateway\r\n\r\n"))
		c.Close()
		return
	}
	req.Header.Del("Proxy-Connection")
	req.Header.Del("Proxy-Authorization")
	if err := req.Write(up); err != nil {
		up.Close()
		c.Close()
		return
	}
	relay(&bufConn{Conn: c, r: br}, up, t.Stats)
}
