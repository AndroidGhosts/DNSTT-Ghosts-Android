package engine

import (
	"testing"
	"time"
)

func TestDNSCacheUsesConfiguredTTL(t *testing.T) {
	now := time.Unix(1_000, 0)
	d := &dnsForwarder{cache: map[string]cacheEntry{}, ttl: 37 * time.Second, maxEntries: 8}
	d.storeCache("query", []byte("answer"), now, 37*time.Second)
	entry, ok := d.cache["query"]
	if !ok {
		t.Fatal("cache entry was not stored")
	}
	if !entry.expires.Equal(now.Add(37 * time.Second)) {
		t.Fatalf("expiry = %v, want %v", entry.expires, now.Add(37*time.Second))
	}
}

func TestDNSCacheEnforcesConfiguredCapacity(t *testing.T) {
	now := time.Unix(2_000, 0)
	d := &dnsForwarder{cache: map[string]cacheEntry{}, ttl: time.Minute, maxEntries: 2}
	d.storeCache("one", []byte("1"), now, time.Minute)
	d.storeCache("two", []byte("2"), now.Add(time.Second), time.Minute)
	d.storeCache("three", []byte("3"), now.Add(2*time.Second), time.Minute)
	if len(d.cache) != 2 {
		t.Fatalf("cache entries = %d, want 2", len(d.cache))
	}
	if _, ok := d.cache["three"]; !ok {
		t.Fatal("newest cache entry was unexpectedly evicted")
	}
}

func TestDNSCachePrunesExpiredEntriesBeforeEviction(t *testing.T) {
	now := time.Unix(3_000, 0)
	d := &dnsForwarder{cache: map[string]cacheEntry{}, ttl: time.Second, maxEntries: 1}
	d.storeCache("expired", []byte("old"), now, time.Second)
	d.storeCache("fresh", []byte("new"), now.Add(2*time.Second), time.Minute)
	if len(d.cache) != 1 {
		t.Fatalf("cache entries = %d, want 1", len(d.cache))
	}
	if _, ok := d.cache["fresh"]; !ok {
		t.Fatal("fresh entry was not stored after expired-entry pruning")
	}
}
