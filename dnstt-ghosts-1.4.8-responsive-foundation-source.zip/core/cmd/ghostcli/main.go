// ghostcli runs the dnstt ghosts engine on desktop for testing.
package main

import (
	"flag"
	"log"
	"os"
	"os/signal"
	"time"

	"github.com/AndroidGhosts/dnstt-ghosts/core/engine"
)

func main() {
	cfgPath := flag.String("config", "config.json", "JSON config file")
	flag.Parse()
	b, err := os.ReadFile(*cfgPath)
	if err != nil {
		log.Fatal(err)
	}
	cfg, err := engine.ParseConfig(string(b))
	if err != nil {
		log.Fatal(err)
	}
	t, err := engine.NewTunnel(cfg)
	if err != nil {
		log.Fatal(err)
	}
	if err := t.StartListeners(); err != nil {
		log.Fatal(err)
	}
	t.Connect()
	go func() {
		for range time.Tick(10 * time.Second) {
			log.Printf("status=%s stats=%s", t.Status(), t.Stats.JSON())
		}
	}()
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	<-sig
	t.Close()
}
