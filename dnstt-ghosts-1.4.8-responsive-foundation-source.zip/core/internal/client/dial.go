package client

import (
	"context"
	"crypto/tls"
	"math/rand"
	"net"
	"sync"
	"time"
)

// FragmentConfig controls splitting of the first outgoing TCP payload (the TLS
// ClientHello) into several small TCP segments, to defeat SNI-based DPI.
type FragmentConfig struct {
	Enabled bool
	MinSize int
	MaxSize int
	Delay   time.Duration
	// Only the first Packets bytes-written calls are fragmented (normally 1).
	Packets int
}

var (
	fragMu  sync.RWMutex
	fragCfg FragmentConfig
)

// SetFragment sets the global fragmentation config used by BaseDialContext.
func SetFragment(c FragmentConfig) {
	if c.MinSize <= 0 {
		c.MinSize = 1
	}
	if c.MaxSize < c.MinSize {
		c.MaxSize = c.MinSize
	}
	if c.Packets <= 0 {
		c.Packets = 1
	}
	fragMu.Lock()
	fragCfg = c
	fragMu.Unlock()
}

func getFragment() FragmentConfig {
	fragMu.RLock()
	defer fragMu.RUnlock()
	return fragCfg
}

// BaseDialContext dials TCP connections to DoH/DoT resolvers, applying
// ClientHello fragmentation when enabled.
var BaseDialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
	d := &net.Dialer{Timeout: dialTimeout, KeepAlive: 30 * time.Second}
	conn, err := d.DialContext(ctx, network, addr)
	if err != nil {
		return nil, err
	}
	fc := getFragment()
	if !fc.Enabled {
		return conn, nil
	}
	if tc, ok := conn.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
	}
	return &fragmentConn{Conn: conn, cfg: fc, remaining: fc.Packets}, nil
}

// StdTLSDialContext dials TLS without uTLS, still going through BaseDialContext.
func StdTLSDialContext(ctx context.Context, network, addr string) (net.Conn, error) {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return nil, err
	}
	conn, err := BaseDialContext(ctx, network, addr)
	if err != nil {
		return nil, err
	}
	tconn := tls.Client(conn, &tls.Config{ServerName: host})
	if err := tconn.HandshakeContext(ctx); err != nil {
		conn.Close()
		return nil, err
	}
	return tconn, nil
}

// UTLSDialContext exposes utlsDialContext for a ClientHello label.
func UTLSDialContext(ctx context.Context, network, addr string, label string) (net.Conn, error) {
	id := utlsLookup(label)
	if id == nil {
		return StdTLSDialContext(ctx, network, addr)
	}
	return utlsDialContext(ctx, network, addr, nil, id)
}

type fragmentConn struct {
	net.Conn
	mu        sync.Mutex
	cfg       FragmentConfig
	remaining int
}

func (c *fragmentConn) Write(p []byte) (int, error) {
	c.mu.Lock()
	if c.remaining <= 0 {
		c.mu.Unlock()
		return c.Conn.Write(p)
	}
	c.remaining--
	c.mu.Unlock()

	written := 0
	for written < len(p) {
		size := c.cfg.MinSize
		if c.cfg.MaxSize > c.cfg.MinSize {
			size += rand.Intn(c.cfg.MaxSize - c.cfg.MinSize + 1)
		}
		end := written + size
		if end > len(p) {
			end = len(p)
		}
		n, err := c.Conn.Write(p[written:end])
		written += n
		if err != nil {
			return written, err
		}
		if c.cfg.Delay > 0 && written < len(p) {
			time.Sleep(c.cfg.Delay)
		}
	}
	return written, nil
}
