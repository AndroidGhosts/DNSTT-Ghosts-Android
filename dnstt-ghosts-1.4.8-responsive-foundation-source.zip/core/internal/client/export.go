package client

import (
	"context"
	"net"
	"net/http"

	utls "github.com/refraction-networking/utls"
	"www.bamsoftware.com/git/dnstt.git/dns"
)

// NumPadding is the number of padding bytes per query (affects MTU).
const NumPadding = numPadding

// NewDNS wraps a transport PacketConn with dnstt DNS encoding.
func NewDNS(transport net.PacketConn, addr net.Addr, domain dns.Name) net.PacketConn {
	return NewDNSPacketConn(transport, addr, domain)
}

// NewDoH creates a DoH transport. label selects a uTLS fingerprint ("none" for Go TLS).
func NewDoH(url string, label string, senders int) (net.PacketConn, error) {
	var rt http.RoundTripper
	id := utlsLookup(label)
	if id == nil {
		transport := http.DefaultTransport.(*http.Transport).Clone()
		transport.Proxy = nil
		transport.DialContext = BaseDialContext
		transport.ForceAttemptHTTP2 = true
		rt = transport
	} else {
		rt = NewUTLSRoundTripper(nil, id)
	}
	return NewHTTPPacketConn(rt, url, senders)
}

// NewDoT creates a DoT transport.
func NewDoT(addr string, label string) (net.PacketConn, error) {
	id := utlsLookup(label)
	var d = StdTLSDialContext
	if id != nil {
		d = func(ctx context.Context, network, addr string) (net.Conn, error) {
			return utlsDialContext(ctx, network, addr, nil, id)
		}
	}
	return NewTLSPacketConn(addr, d)
}

// SampleUTLS picks a fingerprint label from a weighted distribution string
// like "3*Firefox,2*Chrome" (or a single label). Returns "none" for none.
func SampleUTLS(spec string) (string, error) {
	weights, labels, err := parseWeightedList(spec)
	if err != nil {
		return "", err
	}
	for _, l := range labels {
		if l != "none" && utlsLookup(l) == nil {
			return "", &unknownFingerprint{l}
		}
	}
	return labels[sampleWeighted(weights)], nil
}

type unknownFingerprint struct{ label string }

func (e *unknownFingerprint) Error() string { return "unknown TLS fingerprint " + e.label }

// Fingerprints lists the known uTLS labels.
func Fingerprints() []string {
	out := []string{"none"}
	for _, e := range utlsClientHelloIDMap {
		out = append(out, e.Label)
	}
	return out
}

var _ = utls.HelloChrome_Auto
