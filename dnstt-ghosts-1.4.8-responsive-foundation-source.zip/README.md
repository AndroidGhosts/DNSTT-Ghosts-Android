# dnstt ghosts

Android client for [dnstt](https://www.bamsoftware.com/software/dnstt/) (DNS tunnel over DoH / DoT / UDP) with payload segmentation, TLS fragmentation and a full-device VPN.

## Features

- **Transports:** DNS over HTTPS, DNS over TLS, DNS over UDP, DNS over TCP; multiple resolvers with automatic round-robin selection
- **Performance:** per-query payload size and optional TLS ClientHello fragmentation for DoH/DoT
- **uTLS fingerprints** (Chrome, Firefox, iOS, Edge, random, …)
- **Server modes:** SOCKS5 (optional auth), SSH through dnstt (password / private key / host-key pinning), plain port forward
- **Local proxies:** SOCKS5 (optional auth) and HTTP proxy on configurable addresses
- **VPN:** whole-device routing via `VpnService` + gVisor netstack (tun2socks), DNS through the tunnel, IPv6 routing or IPv6 blocking, bypass LAN, MTU, per-app split tunnelling (include / exclude)
- **DNS cache:** manually configurable lifetime (seconds) and maximum entries for DNS forwarded through the VPN TUN
- **Tuning:** KCP window / nodelay / interval / resend, smux buffer, polling interval, idle timeout, keep-alive, auto-reconnect
- Profiles with import/export via `dnstt-ghosts://` links, QR images, safe JSON, clipboard or JSON files; exported credentials are redacted
- Separate upload, download and RTT charts, last-five-minute/full-session view, averages, peaks, jitter and probe loss
- Foreground VPN notification with live upload/download rates, totals, connection duration and expanded RTT/jitter/loss details
- Live local logs, periodic network reachability probes (HTTPS, TLS, DNS and UDP echo), latency test, server keypair generator, Quick Settings tile, start on boot
- Restorable KCP defaults and maximum-speed preset; KCP fast-resend values 1–16
- English and Arabic UI

## Current status and limitations

- App version: `1.4.5-vpn-controls`.
- The vendored dnstt source matches the [official upstream archive `dnstt-20260501`](https://www.bamsoftware.com/software/dnstt/dnstt-20260501.zip); the [official project page](https://www.bamsoftware.com/software/dnstt/) showed no newer source release during this update.
- SSH mode always opens destination streams through `ssh.Client.Dial`; the redundant direct-proxy toggle was removed. SSH compression is unsupported by the current `x/crypto/ssh` transport (which advertises only `none`) and its toggle was removed. The no-delay option forces KCP no-delay; it does not set TCP_NODELAY.
- A real QUIC handshake probe, automatic MTU probing across 1200/1250/1300/1350, exponential reconnect backoff, and guaranteed Wi-Fi/cellular handoff are not implemented in this revision. Unsupported QUIC probing is not offered in the UI.
- The app excludes itself from its VPN, so the optional HTTP/TLS/DNS/UDP probes use the device network and do not validate the tunnel route. This is disclosed in the settings and About screen.
- Cleartext HTTP probes are intentionally unsupported; the HTTPS probe defaults to HTTPS and rejects explicit `http://` URLs rather than enabling app-wide cleartext traffic.
- Android foreground service and periodic probing improve screen-off continuity, but Android/OEM battery policies can still stop or suspend networking.
- App data backup is disabled to reduce exposure of locally stored profiles and credentials. See [`PRIVACY.md`](PRIVACY.md). For Play distribution, host the policy at a public HTTPS URL and complete the current VPN and data-safety declarations. No Play Protect or Play review outcome is guaranteed.
- Before the first VPN connection, the app presents a prominent traffic-routing disclosure and obtains explicit in-app consent before invoking Android's VPN consent dialog.

## Layout

| Path | Contents |
| --- | --- |
| `core/` | Go module: dnstt client (vendored in `third_party/dnstt`), engine (tunnel, SOCKS/HTTP, SSH, TUN), gomobile API in `ghostcore/` |
| `core/cmd/ghostcli` | Desktop CLI that runs the same engine from a JSON config (useful for testing) |
| `app/` | Android app (Kotlin) |

## Build

Requirements: Go ≥ 1.26, Android SDK 34, NDK 26, JDK 17.

```sh
# 1. Build the Go core as an Android library
cd core
go install golang.org/x/mobile/cmd/gomobile@latest golang.org/x/mobile/cmd/gobind@latest
gomobile init
gomobile bind -target=android -androidapi 21 -ldflags="-s -w" -o ../app/libs/ghostcore.aar ./ghostcore

# 2. Build the APKs
cd ..
./gradlew assembleRelease   # or assembleDebug
```

APKs are written to `app/build/outputs/apk/<type>/` (one per ABI plus a universal APK).

Release signing reads `keystore.properties` in the project root (not committed); copy `keystore.properties.example` and point it to your private key:

```properties
storeFile=/path/to/release.jks
storePassword=...
keyAlias=...
keyPassword=...
```

Without it, release builds are signed with the debug key.

Never publish the private keystore or `keystore.properties`. The delivered APK uses a project-specific self-signed release certificate; retain its keystore for compatible updates. A self-signed certificate does not verify the publisher with Google. For Play distribution, use Play App Signing and keep the upload key private.

## Server

Use the stock dnstt server:

```sh
dnstt-server -gen-key -privkey-file server.key -pubkey-file server.pub
# SOCKS mode: forward to a SOCKS5 proxy
dnstt-server -udp :5300 -privkey-file server.key t.example.com 127.0.0.1:1080
# SSH mode: forward to sshd
dnstt-server -udp :5300 -privkey-file server.key t.example.com 127.0.0.1:22
```

## Profile JSON

```json
{
  "name": "My server",
  "domain": "t.example.com",
  "pubkey": "<64 hex chars>",
  "transport": "doh",
  "resolvers": ["https://cloudflare-dns.com/dns-query"],
  "resolverStrategy": "roundrobin",
  "utls": "Chrome_120",
  "segmentSize": 0,
  "fragment": {"enabled": true, "minSize": 1, "maxSize": 5, "delayMs": 5, "packets": 1},
  "mode": "socks",
  "localSocks": "127.0.0.1:1080",
  "localHttp": "127.0.0.1:8080",
  "remoteDns": "8.8.8.8:53"
}
```

## License

dnstt is public domain (see `core/third_party/dnstt`).
