package com.androidghosts.dnsttghosts

/** IPv4 CIDR arithmetic for computing "all public addresses" routes. */
object Routes {
    private val private4 = listOf(
        "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16",
        "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24", "192.168.0.0/16",
        "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "240.0.0.0/4",
        "255.255.255.255/32", "224.0.0.0/4"
    )

    private fun parse(c: String): Pair<Long, Int> {
        val (ip, len) = c.split("/")
        val v = ip.split(".").fold(0L) { acc, s -> (acc shl 8) or s.toLong() }
        return v to len.toInt()
    }

    private fun format(v: Long, len: Int) =
        "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}" to len

    private fun subtract(base: Pair<Long, Int>, ex: Pair<Long, Int>): List<Pair<Long, Int>> {
        val (b, bl) = base
        val (e, el) = ex
        val bMask = if (bl == 0) 0L else (0xFFFFFFFFL shl (32 - bl)) and 0xFFFFFFFFL
        if (el < bl) {
            val eMask = if (el == 0) 0L else (0xFFFFFFFFL shl (32 - el)) and 0xFFFFFFFFL
            return if ((b and eMask) == (e and eMask)) emptyList() else listOf(base)
        }
        if ((e and bMask) != b) return listOf(base)
        if (el == bl) return emptyList()
        val half = 1L shl (31 - bl)
        val lo = b to bl + 1
        val hi = (b or half) to bl + 1
        return subtract(lo, ex) + subtract(hi, ex)
    }

    /** Public IPv4 routes as (address, prefixLength). */
    fun publicV4(): List<Pair<String, Int>> {
        var list = listOf(0L to 0)
        for (ex in private4.map(::parse)) list = list.flatMap { subtract(it, ex) }
        return list.map { format(it.first, it.second) }
    }
}
