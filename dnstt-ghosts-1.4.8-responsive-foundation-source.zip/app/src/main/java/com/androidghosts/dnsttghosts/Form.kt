package com.androidghosts.dnsttghosts

import android.content.Context
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/** Builds settings forms programmatically so every field stays in one place. */
class Form(private val ctx: Context, private val root: LinearLayout) {
    private var current: LinearLayout = root

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun section(titleRes: Int): Form {
        val header = TextView(ctx).apply {
            text = ctx.getString(titleRes)
            textSize = 14f
            setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.accent))
            setPadding(dp(4), dp(12), dp(4), dp(4))
        }
        root.addView(header)
        val card = MaterialCardView(ctx).apply {
            radius = dp(14).toFloat()
            strokeWidth = dp(1)
            strokeColor = androidx.core.content.ContextCompat.getColor(ctx, R.color.card_stroke)
            setCardBackgroundColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.card))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(10))
        }
        card.addView(inner)
        root.addView(card)
        current = inner
        return this
    }

    fun text(
        labelRes: Int, value: String, hintRes: Int = 0, multiline: Boolean = false,
        number: Boolean = false, password: Boolean = false, id: String = ""
    ): TextInputEditText {
        val til = TextInputLayout(ctx).apply {
            hint = ctx.getString(labelRes)
            if (hintRes != 0) helperText = ctx.getString(hintRes)
            isHintAnimationEnabled = false
            if (password) endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(6) }
        }
        val et = TextInputEditText(ctx).apply {
            setText(value)
            tag = id
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                number -> InputType.TYPE_CLASS_NUMBER
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }
            if (multiline) {
                setSingleLine(false)
                minLines = 3
                maxLines = 8
            }
        }
        til.addView(et)
        current.addView(til)
        return et
    }

    fun dropdown(labelRes: Int, labels: List<String>, values: List<String>, selected: String): () -> String {
        val til = TextInputLayout(ctx, null, com.google.android.material.R.attr.textInputOutlinedExposedDropdownMenuStyle).apply {
            hint = ctx.getString(labelRes)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(6) }
        }
        val av = MaterialAutoCompleteTextView(ctx).apply {
            inputType = InputType.TYPE_NULL
            setAdapter(ArrayAdapter(ctx, android.R.layout.simple_list_item_1, labels))
            val i = values.indexOf(selected).coerceAtLeast(0)
            setText(labels[i], false)
        }
        til.addView(av)
        current.addView(til)
        return { values.getOrElse(labels.indexOf(av.text.toString())) { values[0] } }
    }

    fun switch(labelRes: Int, checked: Boolean): MaterialSwitch {
        val sw = MaterialSwitch(ctx).apply {
            text = ctx.getString(labelRes)
            isChecked = checked
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(6) }
        }
        current.addView(sw)
        return sw
    }

    fun note(text: String): TextView {
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = 12f
            setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.text_secondary))
            setPadding(dp(4), dp(6), dp(4), 0)
        }
        current.addView(tv)
        return tv
    }

    fun add(v: View) {
        current.addView(v)
    }
}

fun TextInputEditText.str(): String = text?.toString()?.trim() ?: ""
fun TextInputEditText.int(def: Int = 0): Int = str().toIntOrNull() ?: def
