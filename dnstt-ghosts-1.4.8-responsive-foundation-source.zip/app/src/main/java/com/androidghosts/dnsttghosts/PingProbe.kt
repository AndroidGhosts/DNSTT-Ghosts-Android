package com.androidghosts.dnsttghosts

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.security.SecureRandom
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.roundToLong

object PingProbe {
    data class Result(val ok: Boolean, val rttMs: Long, val detail: String, val supported: Boolean = true)

    fun run(hostInput: String, protocol: String, timeoutMs: Int): Result {
        val timeout = timeoutMs.coerceIn(500, 30_000)
        val start = System.nanoTime()
        return try {
            when (protocol.lowercase()) {
                "http" -> probeHttp(hostInput, timeout, start)
                "ssl" -> probeTls(hostInput, timeout, start)
                "dns" -> probeDns(hostInput, timeout, start)
                "udp" -> probeUdpEcho(hostInput, timeout, start)
                else -> Result(false, elapsed(start), "unsupported protocol: $protocol", supported = false)
            }
        } catch (e: Exception) {
            Result(false, elapsed(start), e.message ?: e.javaClass.simpleName)
        }
    }

    private data class Endpoint(val host: String, val port: Int)

    private fun endpoint(input: String, defaultPort: Int): Endpoint {
        val raw = input.trim()
        val uri = if (raw.contains("://")) URI(raw) else {
            val bare = raw.substringBefore('/')
            if (bare.count { it == ':' } > 1 && !bare.startsWith("[")) URI("tcp://[$bare]") else URI("tcp://$raw")
        }
        val host = uri.host ?: raw.substringBefore('/').substringBeforeLast(':').ifBlank { raw }
        val port = uri.port.takeIf { it > 0 } ?: defaultPort
        return Endpoint(host, port)
    }

    private fun probeHttp(input: String, timeout: Int, start: Long): Result {
        if (input.startsWith("http://", true)) {
            return Result(false, elapsed(start), "Cleartext HTTP is disabled by Android network policy; use HTTPS", supported = false)
        }
        val url = if (input.startsWith("https://", true)) input else "https://$input"
        val c = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.requestMethod = "HEAD"
            c.instanceFollowRedirects = false
            val code = c.responseCode
            return Result(code in 100..599, elapsed(start), "HTTP $code")
        } finally {
            c.disconnect()
        }
    }

    private fun probeTls(input: String, timeout: Int, start: Long): Result {
        val ep = endpoint(input, 443)
        val socket = SSLSocketFactory.getDefault().createSocket() as SSLSocket
        socket.use {
            it.soTimeout = timeout
            it.connect(InetSocketAddress(ep.host, ep.port), timeout)
            it.startHandshake()
        }
        return Result(true, elapsed(start), "TLS handshake ${ep.host}:${ep.port}")
    }

    private fun probeDns(input: String, timeout: Int, start: Long): Result {
        val ep = endpoint(input, 53)
        val id = SecureRandom().nextInt(0x10000)
        val query = byteArrayOf(
            (id shr 8).toByte(), id.toByte(), 0x01, 0x00, 0x00, 0x01,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x07, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(), 'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            0x03, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0x00, 0x00, 0x01, 0x00, 0x01
        )
        DatagramSocket().use { socket ->
            socket.soTimeout = timeout
            socket.connect(InetSocketAddress(ep.host, ep.port))
            socket.send(DatagramPacket(query, query.size))
            val response = ByteArray(2048)
            val packet = DatagramPacket(response, response.size)
            socket.receive(packet)
            if (packet.length < 12 || (((response[0].toInt() and 0xff) shl 8) or (response[1].toInt() and 0xff)) != id || (response[2].toInt() and 0x80) == 0) {
                return Result(false, elapsed(start), "invalid DNS response")
            }
        }
        return Result(true, elapsed(start), "DNS response ${ep.host}:${ep.port}")
    }

    private fun probeUdpEcho(input: String, timeout: Int, start: Long): Result {
        val ep = endpoint(input, 7)
        val payload = "PING".toByteArray(Charsets.US_ASCII)
        DatagramSocket().use { socket ->
            socket.soTimeout = timeout
            socket.connect(InetSocketAddress(ep.host, ep.port))
            socket.send(DatagramPacket(payload, payload.size))
            val response = ByteArray(256)
            val packet = DatagramPacket(response, response.size)
            socket.receive(packet)
            if (packet.length != payload.size || !response.copyOfRange(0, packet.length).contentEquals(payload)) {
                return Result(false, elapsed(start), "UDP responder did not echo the probe payload")
            }
        }
        return Result(true, elapsed(start), "UDP echo ${ep.host}:${ep.port}")
    }

    private fun elapsed(start: Long) = ((System.nanoTime() - start) / 1_000_000.0).roundToLong()
}

data class PingMetricsSnapshot(
    val sent: Long,
    val failed: Long,
    val lastRttMs: Long,
    val averageRttMs: Long,
    val jitterMs: Long
) {
    val lossPercent: Int get() = if (sent > 0) (failed * 100.0 / sent).toInt() else 0
}

object PingMetrics {
    private var sent = 0L
    private var failed = 0L
    private var lastRtt = 0L
    private var averageRtt = 0L
    private var jitter = 0L

    @Synchronized fun reset() {
        sent = 0; failed = 0; lastRtt = 0; averageRtt = 0; jitter = 0
    }

    @Synchronized fun record(result: PingProbe.Result) {
        if (!result.supported) return
        sent++
        if (!result.ok) {
            failed++
            return
        }
        val previous = lastRtt
        lastRtt = result.rttMs
        averageRtt = if (averageRtt == 0L) result.rttMs else (averageRtt * 7 + result.rttMs) / 8
        if (previous > 0) jitter = (jitter * 7 + kotlin.math.abs(result.rttMs - previous)) / 8
    }

    @Synchronized fun snapshot() = PingMetricsSnapshot(sent, failed, lastRtt, averageRtt, jitter)
}
