package com.androidghosts.dnsttghosts

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

class LogActivity : AppCompatActivity() {
    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView
    private val listener: (String) -> Unit = { line ->
        tv.append("\n$line")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple)
        val tb = findViewById<MaterialToolbar>(R.id.toolbar)
        tb.title = getString(R.string.logs)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }

        scroll = ScrollView(this)
        tv = TextView(this).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(24, 24, 24, 24)
            text = LogBuffer.all()
        }
        scroll.addView(tv)
        findViewById<android.widget.FrameLayout>(R.id.content).addView(scroll)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        LogBuffer.listen(listener)
    }

    override fun onDestroy() {
        LogBuffer.unlisten(listener)
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.log, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.l_copy -> {
                clipboard()
                    .setPrimaryClip(ClipData.newPlainText("log", tv.text))
                toast(getString(R.string.copied))
            }
            R.id.l_clear -> {
                LogBuffer.clear()
                tv.text = ""
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}

fun AppCompatActivity.toast(msg: String) =
    android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()

fun android.content.Context.clipboard() =
    getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
