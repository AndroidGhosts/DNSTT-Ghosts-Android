package com.androidghosts.dnsttghosts

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ghostcore.Ghostcore
import org.json.JSONObject

class GhostVpnService : VpnService() {
    private val handler = Handler(Looper.getMainLooper())
    private val lifecycleLock = Any()
    private var profileName = ""
    private var lastUp = 0L
    private var lastDown = 0L
    private var lastSampleElapsedMs = 0L
    private var uploadSpeedBps = 0L
    private var downloadSpeedBps = 0L
    private var lastProbeAt = 0L
    @Volatile private var probeRunning = false
    private var lastLoggedStatus = ""
    @Volatile private var state = STATE_STOPPED

    private val ticker = object : Runnable {
        override fun run() {
            if (!Ghostcore.isRunning()) return
            val status = Ghostcore.status()
            if (status != lastLoggedStatus) {
                LogBuffer.add("CONNECTION state=$status")
                lastLoggedStatus = status
            }
            updateNotification()
            runHealthProbe()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            return START_NOT_STICKY
        }
        synchronized(this) {
            if (state == STATE_STARTING || state == STATE_RUNNING || state == STATE_STOPPING) return START_STICKY
            state = STATE_STARTING
            running = false
        }
        val profile = Profiles.selected(this)
        if (profile == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        profileName = Profiles.displayName(this, profile)
        lastLoggedStatus = ""
        startForegroundCompat(buildNotification(getString(R.string.status_connecting)))
        logDiagnostics(profile)
        Thread { startTunnel(profile) }.start()
        return START_STICKY
    }

    private fun startTunnel(profile: JSONObject) {
        lastSampleElapsedMs = 0L
        lastUp = 0L
        lastDown = 0L
        uploadSpeedBps = 0L
        downloadSpeedBps = 0L
        lastProbeAt = 0L
        lastLoggedStatus = ""
        PingMetrics.reset()
        profileName = Profiles.displayName(this, profile)
        val mode = profile.optString("mode")
        try {
            synchronized(lifecycleLock) {
            if (state != STATE_STARTING) return
            Ghostcore.stop()
            val effective = JSONObject(profile.toString()).apply {
                put("dnsCache", AppSettings.tunnelDnsCache(this@GhostVpnService))
                put("dnsCacheTtlSeconds", AppSettings.dnsCacheTtlSeconds(this@GhostVpnService))
                put("dnsCacheMaxEntries", AppSettings.dnsCacheMaxEntries(this@GhostVpnService))
                put("blockIPv6", AppSettings.blockIpv6(this@GhostVpnService))
                put("remoteDns", AppSettings.tunnelDns(this@GhostVpnService).trim().ifEmpty { optString("remoteDns", "8.8.8.8:53") })
                put("tcpNoDelay", AppSettings.tcpNoDelay(this@GhostVpnService))
                put("payloadClientBufferKB", AppSettings.payloadClientKB(this@GhostVpnService))
                put("payloadRemoteBufferKB", AppSettings.payloadRemoteKB(this@GhostVpnService))
            }
            val selectedProfiles = AppSettings.selectedMultiProfiles(this)
            if (selectedProfiles.size >= 2) {
                val active = org.json.JSONArray()
                for (selected in selectedProfiles.take(5)) {
                    active.put(org.json.JSONObject(selected.toString()).apply {
                        put("dnsCache", AppSettings.tunnelDnsCache(this@GhostVpnService))
                        put("dnsCacheTtlSeconds", AppSettings.dnsCacheTtlSeconds(this@GhostVpnService))
                        put("dnsCacheMaxEntries", AppSettings.dnsCacheMaxEntries(this@GhostVpnService))
                        put("blockIPv6", AppSettings.blockIpv6(this@GhostVpnService))
                        put("remoteDns", AppSettings.tunnelDns(this@GhostVpnService))
                        put("tcpNoDelay", AppSettings.tcpNoDelay(this@GhostVpnService))
                        put("payloadClientBufferKB", AppSettings.payloadClientKB(this@GhostVpnService))
                        put("payloadRemoteBufferKB", AppSettings.payloadRemoteKB(this@GhostVpnService))
                    })
                }
                Ghostcore.startMulti(active.toString())
            } else {
                Ghostcore.start(effective.toString())
            }
            val multiConfigured = selectedProfiles.size >= 2
            if ((multiConfigured || mode != "forward") && !AppSettings.proxyOnly(this)) {
                val mtu = AppSettings.tunMtu(this)
                val pfd = buildVpn(mtu).establish() ?: throw IllegalStateException("VPN not prepared")
                Ghostcore.startVpn(pfd.detachFd().toLong(), mtu.toLong())
            }
            val initialStats = runCatching { JSONObject(Ghostcore.stats()) }.getOrDefault(JSONObject())
            lastUp = initialStats.optLong("bytesUp")
            lastDown = initialStats.optLong("bytesDown")
            lastSampleElapsedMs = SystemClock.elapsedRealtime()
            if (state != STATE_STARTING) {
                Ghostcore.stop()
                return
            }
            state = STATE_RUNNING
            running = true
            handler.post(ticker)
            }
        } catch (e: Exception) {
            LogBuffer.add("start failed: ${e.message}")
            lastError = e.message
            state = STATE_FAILED
            handler.post { stopTunnel() }
        }
    }

    private fun logDiagnostics(profile: JSONObject) {
        val cm = ContextCompat.getSystemService(this, ConnectivityManager::class.java) ?: return
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val lp = network?.let { cm.getLinkProperties(it) }
        val type = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "WIFI"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "MOBILE"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "ETHERNET"
            else -> "UNKNOWN"
        }
        val local = lp?.linkAddresses?.map { it.address.hostAddress }.orEmpty().joinToString(",")
        val dns = lp?.dnsServers?.joinToString(",") { it.hostAddress ?: "?" }.orEmpty()
        val routes = lp?.routes?.joinToString(";") { it.destination.toString() }.orEmpty()
        val resolver = profile.optJSONArray("resolvers")?.optString(0, "unknown") ?: "unknown"
        val auth = when {
            profile.optString("sshKey").isNotBlank() -> "SSH_KEY"
            profile.optString("sshPass").isNotBlank() -> "SSH_PASSWORD"
            else -> "NOT_CONFIGURED"
        }
        LogBuffer.add("DEVICE model=${Build.MANUFACTURER} ${Build.MODEL} api=${Build.VERSION.SDK_INT} abi=${Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"}")
        LogBuffer.add("NETWORK state=${if (network != null) "CONNECTED" else "DISCONNECTED"} type=$type iface=${lp?.interfaceName ?: "?"} localIp=$local mtu=${lp?.mtu ?: 0}")
        LogBuffer.add("NETWORK dns=$dns routes=$routes")
        LogBuffer.add("TUNNEL domain=${profile.optString("domain")} mode=${profile.optString("mode", "socks")} transport=${profile.optString("transport", "udp")} resolver=$resolver")
        LogBuffer.add("AUTH method=$auth sshUser=${profile.optString("sshUser").ifBlank { "none" }} hostKeyPinned=${profile.optString("sshHostKey").isNotBlank()}")
    }

    private fun buildVpn(mtu: Int): Builder {
        val b = Builder()
            .setSession(profileName)
            .setMtu(mtu)
            .addAddress("172.19.0.1", 30)
        AppSettings.tunnelDnsServers(this).forEach { raw ->
            val dns = raw.trim().removePrefix("[").substringBefore("]").substringBefore(":")
            if (dns.isNotEmpty()) runCatching { b.addDnsServer(dns) }
                .onFailure { LogBuffer.add("VPN DNS ignored: ${it.message}") }
        }
        if (AppSettings.bypassLan(this)) {
            Routes.publicV4().forEach { (a, l) -> b.addRoute(a, l) }
        } else {
            b.addRoute("0.0.0.0", 0)
        }
        if (AppSettings.blockIpv6(this)) {
            b.addAddress("fdfe:dcba:9876::1", 126)
            b.addRoute("::", 0)
        } else if (AppSettings.ipv6(this)) {
            b.addAddress("fdfe:dcba:9876::1", 126)
            if (AppSettings.bypassLan(this)) b.addRoute("2000::", 3) else b.addRoute("::", 0)
        }
        val apps = AppSettings.splitApps(this)
        when (AppSettings.splitMode(this)) {
            "include" -> apps.filter { it != packageName }.forEach { runCatching { b.addAllowedApplication(it) } }
            "exclude" -> {
                b.addDisallowedApplication(packageName)
                apps.forEach { runCatching { b.addDisallowedApplication(it) } }
            }
            else -> b.addDisallowedApplication(packageName)
        }
        if (AppSettings.splitMode(this) == "include" && apps.none { it != packageName }) {
            b.addDisallowedApplication(packageName)
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        b.setConfigureIntent(
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        return b
    }

    private fun stopTunnel() {
        synchronized(this) {
            if (state == STATE_STOPPED || state == STATE_STOPPING) return
            state = STATE_STOPPING
        }
        handler.removeCallbacks(ticker)
        Thread {
            synchronized(lifecycleLock) { stopCoreBounded() }
            running = false
            state = STATE_STOPPED
            handler.post {
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
                stopSelf()
            }
        }.start()
    }

    private fun stopCoreBounded() {
        val worker = Thread { runCatching { Ghostcore.stop() } }
        worker.name = "dnstt-core-stop"
        worker.start()
        try {
            worker.join(5000)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        if (worker.isAlive) LogBuffer.add("ERROR shutdown timeout after 5s; stop remains in background")
    }

    private fun runHealthProbe() {
        val now = System.currentTimeMillis()
        val interval = AppSettings.pingIntervalSec(this).coerceIn(3, 300) * 1000L
        if (now - lastProbeAt < interval || probeRunning) return
        lastProbeAt = now
        val host = AppSettings.pingHost(this)
        val protocol = AppSettings.pingProtocol(this)
        probeRunning = true
        Thread({
            try {
            val result = PingProbe.run(host, protocol, AppSettings.pingTimeoutMs(this))
            PingMetrics.record(result)
            val line = when {
                !result.supported -> "NETWORK_PROBE protocol=$protocol target=$host status=unsupported reason=${result.detail}"
                result.ok -> "NETWORK_PROBE protocol=$protocol target=$host rtt=${result.rttMs}ms status=ok"
                else -> "NETWORK_PROBE protocol=$protocol target=$host status=failed reason=${result.detail}"
            }
            LogBuffer.add(line)
            } finally {
                probeRunning = false
            }
        }, "dnstt-health-probe").start()
    }

    override fun onRevoke() = stopTunnel()

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        if (running) Thread {
            synchronized(lifecycleLock) { stopCoreBounded() }
            running = false
        }.start() else running = false
        super.onDestroy()
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(text: String, expandedText: String = text): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GhostVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, App.CHANNEL)
            .setSmallIcon(R.drawable.ic_ghost)
            .setContentTitle(getString(R.string.notif_title, profileName.ifEmpty { getString(R.string.app_name) }))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedText))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.disconnect), stop)
            .build()
    }

    private fun updateNotification() {
        val s = runCatching { JSONObject(Ghostcore.stats()) }.getOrNull() ?: return
        val up = s.optLong("bytesUp"); val down = s.optLong("bytesDown")
        val nowElapsed = SystemClock.elapsedRealtime()
        val elapsed = (nowElapsed - lastSampleElapsedMs).coerceAtLeast(1L)
        if (lastSampleElapsedMs > 0L) {
            uploadSpeedBps = (up - lastUp).coerceAtLeast(0L) * 1000L / elapsed
            downloadSpeedBps = (down - lastDown).coerceAtLeast(0L) * 1000L / elapsed
        }
        val uptime = s.optLong("startedAt").takeIf { it > 0 }?.let { Fmt.duration(System.currentTimeMillis() - it) } ?: "—"
        val ping = PingMetrics.snapshot()
        val loss = if (ping.sent > 0) "${ping.lossPercent}%" else "—"
        val compact = getString(R.string.notif_rates, Fmt.speed(uploadSpeedBps), Fmt.speed(downloadSpeedBps))
        val details = getString(
            R.string.notif_details,
            Fmt.status(this, Ghostcore.status()),
            Fmt.speed(uploadSpeedBps), Fmt.bytes(up),
            Fmt.speed(downloadSpeedBps), Fmt.bytes(down),
            uptime, ping.lastRttMs, ping.jitterMs, loss
        )
        lastUp = up
        lastDown = down
        lastSampleElapsedMs = nowElapsed
        ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
            ?.notify(NOTIF_ID, buildNotification(compact, details))
    }

    companion object {
        const val ACTION_STOP = "stop"
        const val NOTIF_ID = 1
        const val STATE_STOPPED = "STOPPED"
        const val STATE_STARTING = "STARTING"
        const val STATE_RUNNING = "RUNNING"
        const val STATE_STOPPING = "STOPPING"
        const val STATE_FAILED = "FAILED"
        @Volatile var running = false
        @Volatile var lastError: String? = null

        fun start(ctx: Context) {
            lastError = null
            ContextCompat.startForegroundService(ctx, Intent(ctx, GhostVpnService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, GhostVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}

object Fmt {
    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.2f MB", b / 1048576.0)
        else -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun speed(bps: Long) = bytes(maxOf(0, bps)) + "/s"

    fun duration(ms: Long): String {
        val s = ms / 1000
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
    }

    fun status(ctx: Context, s: String): String = when {
        s == "connected" -> ctx.getString(R.string.status_connected)
        s == "connecting" || s == "idle" -> ctx.getString(R.string.status_connecting)
        s.startsWith("error") -> ctx.getString(R.string.status_error) + ": " + s.removePrefix("error: ")
        else -> ctx.getString(R.string.status_stopped)
    }
}
