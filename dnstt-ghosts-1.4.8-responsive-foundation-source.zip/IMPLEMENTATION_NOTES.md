
## Android compatibility and APK build

The Android app now uses `minSdk 30`, so its supported range is Android 11 through Android 17 (API 30–37). It uses `compileSdk 36` and `targetSdk 36` because the project currently uses Android Gradle Plugin 8.5.2, which is tested through SDK 34; targeting 36 builds reliably while remaining compatible with Android 17 runtime behavior.

A universal Debug APK and ABI-specific APKs were built successfully. `lintDebug` also passed. The Debug APK is signed with the standard debug certificate and is intended for testing, not store release. A production Release build still requires the user's own `keystore.properties` and stable release key.
