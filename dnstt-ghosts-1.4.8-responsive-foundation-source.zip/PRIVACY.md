# Privacy policy — dnstt ghosts

**Publisher shown in the app:** Android Ghosts  
**Effective date:** 21 October 2026

## Arabic

يعمل dnstt ghosts كعميل نفق DNS وVPN يضبطه المستخدم. قبل أول اتصال VPN يعرض التطبيق إفصاحًا ويطلب موافقة المستخدم، ثم يعرض Android نافذة موافقته النظامية. لا تتضمن نسخة المشروع تحليلات أو إعلانات أو SDK لتتبّع المستخدم أو إرسال تقارير للمطور.

- **حركة الشبكة:** عند موافقة المستخدم على اتصال Android VPN، تمر حركة التطبيقات التي اختار توجيهها عبر خادم النفق وDNS resolver اللذين أدخلهما المستخدم. يجب الوثوق بمشغّل الخادم وresolver؛ قد يستطيع مشغل الخادم رؤية بيانات الاتصال بعد فك النفق. اختيار DNS عبر UDP غير مشفر، بينما تعتمد حماية DoH/DoT على resolver وإعداداته.
- **الاختبارات:** اختبارات HTTPS/TLS/DNS/UDP الدورية تستخدم الوجهة التي يحددها المستخدم. التطبيق مستثنى من VPN الخاص به، لذلك هذه الاختبارات تقيس الوصول من اتصال الجهاز الخارجي ولا تثبت سلامة النفق. HTTP النصي الصريح غير مدعوم لتجنب تخفيف سياسة أمان Android.
- **البيانات المحلية:** تحفظ الملفات الشخصية والتفضيلات وسجل التشخيص على الجهاز ضمن مساحة التطبيق الخاصة. قد تحتوي الملفات الشخصية على بيانات اعتماد يضيفها المستخدم. يخفي التصدير الآمن كلمات مرور SSH والمفاتيح الخاصة، لكن الروابط وQR/JSON ليست قناة سرية لبقية معلومات الخادم. عُطّل النسخ الاحتياطي للبيانات في هذا الإصدار.
- **الأذونات:** الإنترنت للاتصال بالخادم/Resolver والاختبارات التي يطلبها المستخدم؛ حالة الشبكة لعرض تشخيص محلي؛ خدمة أمامية لإبقاء VPN الذي بدأه المستخدم فعالًا وإظهار إشعار الإيقاف؛ الإشعارات لعرض الحالة؛ استقبال الإقلاع لإتاحة إعادة اتصال اختيارية؛ والاستعلام عن حزم التطبيقات لعرض القائمة اللازمة لاختيار تطبيقات split-tunneling. لا ترسل قائمة التطبيقات للمطور.
- **المشاركة والحذف:** المشاركة أو التصدير يبدأهما المستخدم. حذف بيانات التطبيق من إعدادات Android يزيل ملفاته المحلية. أوقف VPN واحذف الملفات الشخصية التي لم تعد تحتاجها.

للنشر على Google Play، يجب استضافة هذه السياسة على عنوان HTTPS عام وربطها في صفحة المتجر، وإكمال إقرار VPN والبيانات وفق آلية Google الحالية. هذه الوثيقة لا تعني أن Google راجعت التطبيق أو اعتمدته.

## English

`dnstt ghosts` is a user-configured DNS tunnel and VPN client. Before the first VPN connection, the app shows a prominent disclosure and asks for consent, followed by the Android system VPN consent dialog. This project build includes no analytics, advertising, user-tracking SDK, or developer telemetry endpoint.

- **Network traffic:** After the user approves Android VPN, traffic from apps selected for routing goes through the tunnel server and DNS resolver entered by the user. Users should trust those operators; the server operator may see traffic after tunnel decryption. DNS over UDP is unencrypted; DoH/DoT protection depends on the selected resolver and its configuration.
- **Probes:** Periodic HTTPS/TLS/DNS/UDP probes contact the user-selected target. The app is excluded from its own VPN, so these probes measure reachability over the device network and do not verify the tunnel path. Cleartext HTTP is unsupported to avoid weakening Android network security policy.
- **Local data:** Profiles, preferences, and diagnostic logs are stored in the app-private device area. Profiles may contain credentials entered by the user. Safe exports redact SSH passwords and private keys, but links/QR/JSON are not confidential channels for other server details. App data backup is disabled in this revision.
- **Permissions:** Internet for user-configured server/resolver connections and requested probes; network state for local diagnostics; foreground service for the user-started VPN and its stop notification; notifications for status; boot receiver for optional reconnect; and package visibility to populate the app picker for split tunneling. The installed-app list is not sent to the developer.
- **Sharing and deletion:** Export or sharing is user-initiated. Clearing app data in Android settings removes local app files. Disconnect the VPN and delete profiles you no longer need.

For Google Play distribution, host this policy at a public HTTPS URL, link it from the store listing, and complete the current VPN/data declarations. This document does not imply Google has reviewed or approved the app.
