#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java/JDK is missing. Install JDK 17 in AndroidIDE first." >&2
  exit 2
fi
java_version="$(java -version 2>&1 | head -n 1)"
echo "Java: ${java_version}"
if ! java -version 2>&1 | grep -Eq 'version "(17|21|22|23|24|25)(\.|")'; then
  echo "WARNING: Android Gradle Plugin 8.9.1 needs JDK 17+. Verify your Java version if Gradle fails." >&2
fi

chmod +x ./gradlew
./gradlew --no-daemon --stacktrace assembleDebug

out="app/build/outputs/apk/debug"
if [ ! -d "$out" ]; then
  echo "ERROR: Build task ended but APK output directory is missing." >&2
  exit 3
fi
mapfile -t apks < <(find "$out" -maxdepth 1 -type f -name '*.apk' -print | sort)
if [ "${#apks[@]}" -eq 0 ]; then
  echo "ERROR: Gradle reported success but no APK was found in $out." >&2
  exit 4
fi
printf '\nAPK files generated:\n'
for apk in "${apks[@]}"; do
  ls -lh "$apk"
done
