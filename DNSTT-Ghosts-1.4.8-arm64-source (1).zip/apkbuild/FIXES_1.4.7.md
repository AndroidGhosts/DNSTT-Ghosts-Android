# Android_Ghosts 1.4.7 — Source Fix Report

This document describes changes made to the source archive. The app APK was not rebuilt in this environment; see the build limitation below.

## Changes

- Compacted the main dashboard in `activity_main.xml` (smaller primary button, graph area, padding and gaps) to reduce unnecessary vertical height on phone screens while retaining scrollability.
- Clarified that **VPN DNS** is the numeric DNS IP announced on Android's TUN interface, while **Upstream DNS through tunnel** is the `host:port` reached by the app's DNS-forwarder. Numeric VPN DNS addresses are validated, invalid values are not saved over the last valid value, and bracketed IPv6 host:port syntax is supported for upstream DNS.
- Applied the global upstream DNS override to both single- and multi-tunnel configuration. Empty global override preserves each profile's `remoteDns` value.
- Corrected split tunneling's include mode so that zero selected apps or only stale/uninstalled selections fail safely rather than accidentally routing every app through the VPN. The main screen now warns before requesting VPN permission when include mode has no apps selected.
- Fixed KCP/smux buffer precedence: profile `smuxBufferKB` values are respected by default; global payload-buffer values override profiles only after deliberate user edits. Added a button to restore profile-specific buffers.
- Restored upstream-compatible DNSTT KCP defaults in the profile editor: no-delay off, interval/resend set to their default/unused values, window `0` (resolves to `QueueSize / 2 = 64` packets in this vendored DNSTT source), smux buffer 1024 KB, idle timeout 120 s, keepalive 10 s. The turbo preset is more aggressive but is not guaranteed to improve speed.
- Kept profile credentials when exporting/copying/sharing `dnstt-ghosts://` links and JSON. Old credential field aliases are migrated to current names, including SSH/SOCKS passwords and SSH private-key passphrase. Full exports contain secrets; share them only with trusted recipients.
- Added a graceful fallback when a credential-rich profile (often an SSH private key) is too large for QR encoding; link and full JSON export remain available instead of the export dialog crashing.
- Updated version to `1.4.7-device-fixes` / `versionCode 11` and corrected English/Arabic labels and hints.

## Stability assessment

Source review found and fixed the specific logic issues listed above. This does **not** prove end-to-end tunnel stability. That requires rebuilding and exercising the app on the actual phone with reachable, compatible DNSTT server(s), and testing UDP/DoH/DoT, reconnects, screen-off/background behavior, DNS, KCP turbo on/off, one tunnel vs multi-tunnel, split apps, and export/import round-trips. Multi-tunnel mode selects a tunnel for new TCP flows; it does not combine multiple tunnels into one TCP stream or guarantee summed bandwidth.

## Verification performed

- Parsed all 22 Android XML resource/layout files: no malformed XML.
- Checked default English string resources for missing `R.string` references from Kotlin: none found.
- Checked English/Arabic changed resource files for duplicate names: none found.
- **Android build and Go tests were not run successfully** in this environment: Gradle 8.7 download failed because `services.gradle.org` was unreachable, Android SDK environment variables were not configured, and the included Go module requires Go 1.26+ while the available Go toolchain is older. Do not treat this archive as a verified APK.
