import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

val hasReleaseSigning = keystoreProps.isNotEmpty()
if (!hasReleaseSigning && gradle.startParameter.taskNames.any { it.lowercase().contains("release") }) {
    throw GradleException("Release build requires keystore.properties; refusing to fall back to the debug key")
}

android {
    namespace = "com.androidghosts.dnsttghosts"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.androidghosts.dnsttghosts"
        minSdk = 30
        targetSdk = 36
        versionCode = 12
        versionName = "1.4.8-arm64"
        // This build is intentionally for 64-bit ARM Android phones only.
        ndk { abiFilters += setOf("arm64-v8a") }
    }

    signingConfigs {
        if (keystoreProps.isNotEmpty()) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs.useLegacyPackaging = true
    }
}

dependencies {
    implementation(files("libs/ghostcore.aar"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")
}

// Fail early if the bundled native engine does not contain the required ARM64 library.
tasks.register("verifyGhostcoreArm64") {
    doLast {
        val aar = file("libs/ghostcore.aar")
        if (!aar.exists()) throw GradleException("Missing app/libs/ghostcore.aar")
        val zip = java.util.zip.ZipFile(aar)
        try {
            val entry = zip.getEntry("jni/arm64-v8a/libgojni.so")
                ?: throw GradleException("ghostcore.aar does not include jni/arm64-v8a/libgojni.so")
            if (entry.size <= 0L) throw GradleException("ARM64 libgojni.so is empty")
            logger.lifecycle("Verified ghostcore ARM64 native library: ${entry.size()} bytes")
        } finally {
            zip.close()
        }
    }
}

tasks.configureEach {
    if (name == "preBuild") dependsOn("verifyGhostcoreArm64")
}
