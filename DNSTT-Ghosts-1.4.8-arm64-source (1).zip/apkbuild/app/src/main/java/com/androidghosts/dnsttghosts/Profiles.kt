package com.androidghosts.dnsttghosts

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Profiles {
    private const val PREFS = "profiles"
    private const val KEY_LIST = "list"
    private const val KEY_SELECTED = "selected"
    const val LINK_SCHEME = "dnstt-ghosts://"

    fun defaults(): JSONObject = JSONObject().apply {
        put("id", UUID.randomUUID().toString())
        put("name", "")
        put("domain", "")
        put("pubkey", "")
        put("transport", "udp")
        put("resolvers", JSONArray(listOf("8.8.8.8:53")))
        put("resolverStrategy", "roundrobin")
        put("remoteDns", "8.8.8.8:53")
        put("utls", "Chrome_120")
        put("dohSenders", 32)
        put("segmentSize", 0)
        put("fragment", JSONObject().apply {
            put("enabled", false); put("minSize", 1); put("maxSize", 5); put("delayMs", 5); put("packets", 1)
        })
        put("mode", "socks")
        put("socksUser", ""); put("socksPass", ""); put("socksFast", true)
        put("sshUser", ""); put("sshPass", ""); put("sshKey", ""); put("sshKeyPass", ""); put("sshHostKey", "")
        put("localSocks", "127.0.0.1:1080")
        put("localSocksUser", ""); put("localSocksPass", "")
        put("localHttp", "")
        put("localForward", "127.0.0.1:7000")
        put("dnsCache", true)
        put("pollMinMs", 500); put("pollMaxMs", 10000)
        put("kcpWindow", 0); put("kcpNoDelay", false); put("kcpIntervalMs", 0); put("kcpResend", 0)
        put("smuxBufferKB", 1024)
        put("idleTimeoutSec", 120); put("keepAliveSec", 10); put("reconnectSec", 3)
    }

    /** Fill missing keys from defaults so old/imported profiles get every field. */
    fun normalize(p: JSONObject): JSONObject {
        val d = defaults()
        val out = JSONObject(d.toString())
        p.keys().forEach { k -> out.put(k, p.get(k)) }
        val frag = d.getJSONObject("fragment")
        p.optJSONObject("fragment")?.let { f -> f.keys().forEach { frag.put(it, f.get(it)) } }
        out.put("fragment", frag)

        // Accept legacy profile exporters that used alternate credential field names.
        // Canonical fields used by the current UI are always included in exports.
        val aliases = linkedMapOf(
            "sshPass" to listOf("sshPassword", "ssh_password"),
            "socksPass" to listOf("socksPassword", "socks_password"),
            "localSocksPass" to listOf("localSocksPassword", "local_socks_password"),
            "sshKeyPass" to listOf("sshKeyPassword", "ssh_key_password"),
            "sshKey" to listOf("privateKey", "private_key")
        )
        aliases.forEach { (canonical, oldNames) ->
            if (out.optString(canonical).isEmpty()) {
                oldNames.firstNotNullOfOrNull { key -> p.optString(key).takeIf { it.isNotEmpty() } }
                    ?.let { out.put(canonical, it) }
            }
        }
        // Very old generic user/password profiles were mode-dependent.
        if (p.optString("password").isNotEmpty()) {
            val target = if (out.optString("mode") == "ssh") "sshPass" else "socksPass"
            if (out.optString(target).isEmpty()) out.put(target, p.optString("password"))
        }
        if (p.optString("username").isNotEmpty()) {
            val target = if (out.optString("mode") == "ssh") "sshUser" else "socksUser"
            if (out.optString(target).isEmpty()) out.put(target, p.optString("username"))
        }
        if (out.optString("id").isEmpty()) out.put("id", UUID.randomUUID().toString())
        return out
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun list(ctx: Context): MutableList<JSONObject> {
        val arr = JSONArray(prefs(ctx).getString(KEY_LIST, "[]"))
        return (0 until arr.length()).map { normalize(arr.getJSONObject(it)) }.toMutableList()
    }

    private fun saveList(ctx: Context, list: List<JSONObject>) {
        prefs(ctx).edit().putString(KEY_LIST, JSONArray(list).toString()).apply()
    }

    fun get(ctx: Context, id: String?): JSONObject? = list(ctx).firstOrNull { it.optString("id") == id }

    fun save(ctx: Context, p: JSONObject) {
        val list = list(ctx)
        val i = list.indexOfFirst { it.optString("id") == p.optString("id") }
        if (i >= 0) list[i] = p else list.add(p)
        saveList(ctx, list)
        if (selectedId(ctx) == null) select(ctx, p.optString("id"))
    }

    fun delete(ctx: Context, id: String) {
        saveList(ctx, list(ctx).filter { it.optString("id") != id })
        if (selectedId(ctx) == id) prefs(ctx).edit().remove(KEY_SELECTED).apply()
    }

    fun duplicate(ctx: Context, p: JSONObject): JSONObject {
        val c = JSONObject(p.toString())
        c.put("id", UUID.randomUUID().toString())
        c.put("name", p.optString("name") + " (2)")
        save(ctx, c)
        return c
    }

    fun selectedId(ctx: Context): String? = prefs(ctx).getString(KEY_SELECTED, null)
    fun select(ctx: Context, id: String) = prefs(ctx).edit().putString(KEY_SELECTED, id).apply()
    fun selected(ctx: Context): JSONObject? = get(ctx, selectedId(ctx)) ?: list(ctx).firstOrNull()

    fun toLink(p: JSONObject): String {
        val c = exportableProfile(p)
        return LINK_SCHEME + Base64.encodeToString(c.toString().toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    /** Complete export: deliberately preserves passwords and other credentials. */
    fun toProfileJson(p: JSONObject): String = exportableProfile(p).toString(2)

    /** Kept for compatibility with earlier callers; this is a complete, not redacted, export. */
    fun toSafeJson(p: JSONObject): String = toProfileJson(p)

    private fun exportableProfile(p: JSONObject): JSONObject {
        val c = normalize(JSONObject(p.toString()))
        c.remove("id")
        return c
    }

    /** Parse a dnstt-ghosts:// link, a dnstt:// link or raw JSON. */
    fun parse(text: String): JSONObject? {
        val t = text.trim()
        return try {
            val json = when {
                t.startsWith("{") -> t
                t.startsWith(LINK_SCHEME) || t.startsWith("dnstt://") ->
                    String(Base64.decode(t.substringAfter("://").substringBefore("#"), Base64.URL_SAFE or Base64.NO_WRAP), Charsets.UTF_8)
                else -> return null
            }
            val p = normalize(JSONObject(json))
            p.put("id", UUID.randomUUID().toString())
            if (p.optString("domain").isEmpty() || p.optString("pubkey").isEmpty()) null else p
        } catch (e: Exception) {
            null
        }
    }

    fun displayName(ctx: Context, p: JSONObject): String =
        p.optString("name").ifEmpty { p.optString("domain").ifEmpty { ctx.getString(R.string.unnamed) } }
}

object AppSettings {
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun proxyOnly(ctx: Context) = p(ctx).getBoolean("proxy_only", false)
    fun ipv6(ctx: Context) = p(ctx).getBoolean("ipv6", true)
    fun blockIpv6(ctx: Context) = p(ctx).getBoolean("block_ipv6", false)
    fun bypassLan(ctx: Context) = p(ctx).getBoolean("bypass_lan", true)
    fun tunMtu(ctx: Context) = p(ctx).getInt("tun_mtu", 1500)
    fun vpnDns(ctx: Context) = p(ctx).getString("vpn_dns", "8.8.8.8")!!
    fun autoDns(ctx: Context) = p(ctx).getBoolean("auto_dns", true)
    // Empty means: keep the profile's remoteDns (which defaults to resolver:53).
    fun tunnelDns(ctx: Context) = p(ctx).getString("tunnel_dns", "")!!
    fun tunnelDnsCache(ctx: Context) = p(ctx).getBoolean("tunnel_dns_cache", true)
    fun dnsCacheTtlSeconds(ctx: Context) = p(ctx).getInt("dns_cache_ttl_seconds", 120)
    fun dnsCacheMaxEntries(ctx: Context) = p(ctx).getInt("dns_cache_max_entries", 2048)
    fun tcpNoDelay(ctx: Context) = p(ctx).getBoolean("tcp_no_delay", false)
    fun payloadClientKB(ctx: Context): Int = if (payloadBuffersOverride(ctx)) p(ctx).getInt("payload_client_kb", 1024) else 1024
    fun payloadRemoteKB(ctx: Context): Int = if (payloadBuffersOverride(ctx)) p(ctx).getInt("payload_remote_kb", 4096) else 4096
    fun payloadBuffersOverride(ctx: Context): Boolean {
        val prefs = p(ctx)
        if (prefs.contains("payload_buffers_override")) return prefs.getBoolean("payload_buffers_override", false)
        // Migrate intentional values from the previous release. Its unchanged defaults were 16/32 MiB.
        val oldClient = prefs.getInt("payload_client_kb", 16384)
        val oldRemote = prefs.getInt("payload_remote_kb", 32768)
        val wasCustomized = (prefs.contains("payload_client_kb") && oldClient != 16384) ||
            (prefs.contains("payload_remote_kb") && oldRemote != 32768)
        prefs.edit()
            .putBoolean("payload_buffers_override", wasCustomized)
            .putInt("payload_client_kb", if (wasCustomized) oldClient else 1024)
            .putInt("payload_remote_kb", if (wasCustomized) oldRemote else 4096)
            .apply()
        return wasCustomized
    }
    fun pingHost(ctx: Context) = p(ctx).getString("ping_host", "1.1.1.1")!!
    fun pingProtocol(ctx: Context): String = p(ctx).getString("ping_protocol", "http")!!
        .takeIf { it in setOf("udp", "http", "dns", "ssl") } ?: "http"
    fun pingIntervalSec(ctx: Context) = p(ctx).getInt("ping_interval_sec", 10)
    fun pingTimeoutMs(ctx: Context) = p(ctx).getInt("ping_timeout_ms", 3000)
    fun multiCount(ctx: Context) = p(ctx).getInt("multi_count", 1)
    fun multiProfiles(ctx: Context): JSONArray = runCatching { JSONArray(p(ctx).getString("multi_profiles", "[]")) }.getOrDefault(JSONArray())
    fun multiProfileIds(ctx: Context): Set<String> = p(ctx).getStringSet("multi_profile_ids", emptySet()) ?: emptySet()
    fun selectedMultiProfiles(ctx: Context): List<JSONObject> = multiProfileIds(ctx)
        .mapNotNull { id -> Profiles.get(ctx, id) }
        .take(5)
    fun splitMode(ctx: Context) = p(ctx).getString("split_mode", "all")!!
    fun splitApps(ctx: Context): Set<String> = p(ctx).getStringSet("split_apps", emptySet())!!
    fun boot(ctx: Context) = p(ctx).getBoolean("boot", false)
    fun edit(ctx: Context) = p(ctx).edit()
    fun saveMulti(ctx: Context, count: Int, profiles: JSONArray) = p(ctx).edit()
        .putInt("multi_count", count.coerceIn(1, 5))
        .putString("multi_profiles", profiles.toString())
        .apply()
    fun saveMultiProfileIds(ctx: Context, ids: Set<String>) = p(ctx).edit()
        .putStringSet("multi_profile_ids", ids.take(5).toSet())
        .putInt("multi_count", ids.size.coerceIn(1, 5))
        .apply()
}
