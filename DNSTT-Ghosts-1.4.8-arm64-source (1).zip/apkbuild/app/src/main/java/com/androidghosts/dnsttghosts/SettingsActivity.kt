package com.androidghosts.dnsttghosts

import android.content.Intent
import android.os.Bundle
import android.net.InetAddresses
import android.widget.Toast
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import com.google.android.material.button.MaterialButton

class SettingsActivity : AppCompatActivity() {
    private lateinit var appsButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple)
        val tb = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        tb.title = getString(R.string.settings)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }

        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 0, 32, 64) }
        findViewById<android.widget.FrameLayout>(R.id.content).addView(NestedScrollView(this).apply { addView(container) })
        val f = Form(this, container)
        val ctx = this

        f.section(R.string.s_vpn)
        f.note(getString(R.string.vpn_options_summary))
        f.switch(R.string.s_proxy_only, AppSettings.proxyOnly(ctx)).setOnCheckedChangeListener { _, v ->
            AppSettings.edit(ctx).putBoolean("proxy_only", v).apply()
        }
        val routeIpv6 = f.switch(R.string.s_ipv6, AppSettings.ipv6(ctx))
        val blockIpv6 = f.switch(R.string.s_block_ipv6, AppSettings.blockIpv6(ctx))
        if (routeIpv6.isChecked && blockIpv6.isChecked) blockIpv6.isChecked = false
        f.note(getString(R.string.s_ipv6_block_note))
        routeIpv6.setOnCheckedChangeListener { _, v ->
            AppSettings.edit(ctx).putBoolean("ipv6", v).apply()
            if (v && blockIpv6.isChecked) blockIpv6.isChecked = false
        }
        blockIpv6.setOnCheckedChangeListener { _, v ->
            AppSettings.edit(ctx).putBoolean("block_ipv6", v).apply()
            if (v && routeIpv6.isChecked) routeIpv6.isChecked = false
        }
        f.switch(R.string.s_bypass_lan, AppSettings.bypassLan(ctx)).setOnCheckedChangeListener { _, v ->
            AppSettings.edit(ctx).putBoolean("bypass_lan", v).apply()
        }
        val mtu = f.text(R.string.s_tun_mtu, AppSettings.tunMtu(ctx).toString(), number = true)
        val vpnDns = f.text(R.string.s_vpn_dns, AppSettings.vpnDns(ctx), R.string.s_vpn_dns_h)
        val tunnelDns = f.text(R.string.s_tunnel_dns, AppSettings.tunnelDns(ctx), R.string.f_remote_dns_h)
        f.section(R.string.sec_dns)
        val tunnelDnsCache = f.switch(R.string.s_tunnel_dns_cache, AppSettings.tunnelDnsCache(ctx))
        val dnsCacheTtl = f.text(R.string.s_dns_cache_ttl, AppSettings.dnsCacheTtlSeconds(ctx).toString(), number = true)
        val dnsCacheEntries = f.text(R.string.s_dns_cache_entries, AppSettings.dnsCacheMaxEntries(ctx).toString(), number = true)
        f.note(getString(R.string.s_dns_cache_note))
        f.section(R.string.s_ssh_options)
        val tcpNoDelay = f.switch(R.string.s_tcp_no_delay, AppSettings.tcpNoDelay(ctx))
        f.note(getString(R.string.s_ssh_options_note))
        f.note(getString(R.string.s_tcp_no_delay_note))
        f.section(R.string.s_payload)
        val payloadClient = f.text(R.string.s_payload_client, AppSettings.payloadClientKB(ctx).toString(), number = true)
        val payloadRemote = f.text(R.string.s_payload_remote, AppSettings.payloadRemoteKB(ctx).toString(), number = true)
        var payloadBuffersTouched = false
        payloadClient.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { payloadBuffersTouched = true }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        payloadRemote.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { payloadBuffersTouched = true }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        f.add(MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.s_use_profile_buffers)
            setOnClickListener {
                payloadBuffersTouched = false
                AppSettings.edit(ctx).putBoolean("payload_buffers_override", false).apply()
                Toast.makeText(ctx, R.string.s_profile_buffers_enabled, Toast.LENGTH_SHORT).show()
            }
        })
        f.note(getString(R.string.restart_needed))

        f.section(R.string.s_ping)
        val pingHost = f.text(R.string.s_ping_host, AppSettings.pingHost(ctx))
        f.note(getString(R.string.s_ping_help))
        val pingProtocol = f.dropdown(
            R.string.s_ping_protocol,
            listOf(getString(R.string.ping_udp), getString(R.string.ping_http), getString(R.string.ping_dns), getString(R.string.ping_ssl)),
            listOf("udp", "http", "dns", "ssl"), AppSettings.pingProtocol(ctx)
        )
        val pingInterval = f.text(R.string.s_ping_interval, AppSettings.pingIntervalSec(ctx).toString(), number = true)
        val pingTimeout = f.text(R.string.s_ping_timeout, AppSettings.pingTimeoutMs(ctx).toString(), number = true)

        f.section(R.string.s_split)
        val split = f.dropdown(
            R.string.s_split,
            listOf(getString(R.string.s_split_all), getString(R.string.s_split_include), getString(R.string.s_split_exclude)),
            listOf("all", "include", "exclude"), AppSettings.splitMode(ctx)
        )
        appsButton = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            setOnClickListener { startActivity(Intent(ctx, AppsActivity::class.java)) }
        }
        f.add(appsButton)

        f.section(R.string.multi_tunnels)
        val multiButton = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.multi_configure, AppSettings.multiProfileIds(ctx).size)
            setOnClickListener { startActivity(Intent(ctx, MultiTunnelActivity::class.java)) }
        }
        f.add(multiButton)

        f.section(R.string.s_general)
        f.switch(R.string.s_boot, AppSettings.boot(ctx)).setOnCheckedChangeListener { _, v ->
            AppSettings.edit(ctx).putBoolean("boot", v).apply()
        }

        saveOnPause = {
            val rawVpnDns = vpnDns.str().trim()
            val validVpnDns = when {
                rawVpnDns.isBlank() -> "8.8.8.8"
                runCatching { InetAddresses.parseNumericAddress(rawVpnDns); true }.getOrDefault(false) -> rawVpnDns
                else -> {
                    vpnDns.error = getString(R.string.s_vpn_dns_invalid)
                    Toast.makeText(ctx, R.string.s_vpn_dns_invalid, Toast.LENGTH_LONG).show()
                    AppSettings.vpnDns(ctx).takeIf { saved ->
                        runCatching { InetAddresses.parseNumericAddress(saved); true }.getOrDefault(false)
                    } ?: "8.8.8.8"
                }
            }
            if (rawVpnDns.isBlank() || validVpnDns == rawVpnDns) vpnDns.error = null

            val rawTunnelDns = tunnelDns.str().trim()
            val validTunnelDns = when {
                rawTunnelDns.isBlank() -> ""
                runCatching {
                    val uri = java.net.URI("tcp://$rawTunnelDns")
                    !uri.host.isNullOrBlank() && uri.port in 1..65535 && uri.rawUserInfo == null &&
                        uri.rawPath.isNullOrEmpty() && uri.query == null && uri.fragment == null
                }.getOrDefault(false) -> rawTunnelDns
                else -> {
                    tunnelDns.error = getString(R.string.s_tunnel_dns_invalid)
                    Toast.makeText(ctx, R.string.s_tunnel_dns_invalid, Toast.LENGTH_LONG).show()
                    AppSettings.tunnelDns(ctx).takeIf { saved ->
                        runCatching {
                            val uri = java.net.URI("tcp://$saved")
                            !uri.host.isNullOrBlank() && uri.port in 1..65535 && uri.rawUserInfo == null &&
                                uri.rawPath.isNullOrEmpty() && uri.query == null && uri.fragment == null
                        }.getOrDefault(false)
                    } ?: ""
                }
            }
            if (rawTunnelDns.isBlank() || validTunnelDns == rawTunnelDns) tunnelDns.error = null

            val editor = AppSettings.edit(ctx)
                .putBoolean("ipv6", routeIpv6.isChecked)
                .putBoolean("block_ipv6", blockIpv6.isChecked)
                .putInt("tun_mtu", mtu.int(1500).coerceIn(576, 9000))
                .putString("vpn_dns", validVpnDns)
                .putString("tunnel_dns", validTunnelDns)
                .putBoolean("tunnel_dns_cache", tunnelDnsCache.isChecked)
                .putInt("dns_cache_ttl_seconds", dnsCacheTtl.int(120).coerceIn(1, 86400))
                .putInt("dns_cache_max_entries", dnsCacheEntries.int(2048).coerceIn(64, 65536))
                .putBoolean("tcp_no_delay", tcpNoDelay.isChecked)
                .putInt("payload_client_kb", payloadClient.int(1024).coerceIn(256, 131072))
                .putInt("payload_remote_kb", payloadRemote.int(4096).coerceIn(512, 262144))
                .putString("ping_host", pingHost.str().trim().ifEmpty { "1.1.1.1" })
                .putString("ping_protocol", pingProtocol())
                .putInt("ping_interval_sec", pingInterval.int(10).coerceIn(3, 300))
                .putInt("ping_timeout_ms", pingTimeout.int(3000).coerceIn(500, 30000))
                .putString("split_mode", split())
            val currentlyOverridden = AppSettings.payloadBuffersOverride(ctx)
            editor.putBoolean("payload_buffers_override", payloadBuffersTouched || currentlyOverridden)
            editor.apply()
        }
    }

    private var saveOnPause: () -> Unit = {}

    override fun onResume() {
        super.onResume()
        appsButton.text = getString(R.string.s_select_apps, AppSettings.splitApps(this).size)
    }

    override fun onPause() {
        saveOnPause()
        super.onPause()
    }
}
