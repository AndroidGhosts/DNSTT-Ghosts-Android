package com.androidghosts.dnsttghosts

import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class AppsActivity : AppCompatActivity() {
    data class AppItem(val pkg: String, val label: String, val icon: Drawable, val system: Boolean)

    private val selected = mutableSetOf<String>()
    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private var query = ""
    private var showSystem = false
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple)
        val tb = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        tb.title = getString(R.string.s_split)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }
        selected += AppSettings.splitApps(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val til = TextInputLayout(this).apply { hint = getString(R.string.s_search_apps) }
        val search = TextInputEditText(this).apply { setSingleLine() }
        til.addView(search)
        root.addView(til)
        val sys = MaterialSwitch(this).apply { text = getString(R.string.s_show_system) }
        root.addView(sys)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@AppsActivity)
            adapter = this@AppsActivity.adapter
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(rv)
        findViewById<android.widget.FrameLayout>(R.id.content).addView(root)

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { query = s.toString(); filter() }
        })
        sys.setOnCheckedChangeListener { _, v -> showSystem = v; filter() }

        Thread {
            val pm = packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { it.packageName != packageName }
                .map {
                    AppItem(
                        it.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm),
                        it.flags and ApplicationInfo.FLAG_SYSTEM != 0
                    )
                }
                .sortedWith(compareBy({ it.pkg !in selected }, { it.label.lowercase() }))
            runOnUiThread { all = apps; filter() }
        }.start()
    }

    private fun filter() {
        shown = all.filter {
            (showSystem || !it.system || it.pkg in selected) &&
                (query.isEmpty() || it.label.contains(query, true) || it.pkg.contains(query, true))
        }
        adapter.notifyDataSetChanged()
    }

    override fun onPause() {
        AppSettings.edit(this).putStringSet("split_apps", selected.toSet()).apply()
        super.onPause()
    }

    inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(val cb: CheckBox) : RecyclerView.ViewHolder(cb)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val cb = CheckBox(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setPadding(16, 20, 16, 20)
                compoundDrawablePadding = 24
            }
            return VH(cb)
        }

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val a = shown[i]
            h.cb.setOnCheckedChangeListener(null)
            h.cb.text = "${a.label}\n${a.pkg}"
            h.cb.isChecked = a.pkg in selected
            val size = (36 * resources.displayMetrics.density).toInt()
            a.icon.setBounds(0, 0, size, size)
            h.cb.setCompoundDrawablesRelative(null, null, a.icon, null)
            h.cb.setOnCheckedChangeListener { _, v -> if (v) selected += a.pkg else selected -= a.pkg }
        }
    }
}
