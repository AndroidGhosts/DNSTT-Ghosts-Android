package com.androidghosts.dnsttghosts

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import com.google.android.material.button.MaterialButton
import ghostcore.Ghostcore
import org.json.JSONArray
import org.json.JSONObject

class ProfileEditActivity : AppCompatActivity() {
    private lateinit var p: JSONObject
    private val f by lazy { Form(this, container) }
    private lateinit var container: LinearLayout

    private lateinit var name: com.google.android.material.textfield.TextInputEditText
    private lateinit var domain: com.google.android.material.textfield.TextInputEditText
    private lateinit var pubkey: com.google.android.material.textfield.TextInputEditText
    private lateinit var resolvers: com.google.android.material.textfield.TextInputEditText
    private lateinit var remoteDns: com.google.android.material.textfield.TextInputEditText
    private lateinit var utls: com.google.android.material.textfield.TextInputEditText
    private lateinit var dohSenders: com.google.android.material.textfield.TextInputEditText
    private lateinit var segment: com.google.android.material.textfield.TextInputEditText
    private lateinit var fragMin: com.google.android.material.textfield.TextInputEditText
    private lateinit var fragMax: com.google.android.material.textfield.TextInputEditText
    private lateinit var fragDelay: com.google.android.material.textfield.TextInputEditText
    private lateinit var fragPackets: com.google.android.material.textfield.TextInputEditText
    private lateinit var socksUser: com.google.android.material.textfield.TextInputEditText
    private lateinit var socksPass: com.google.android.material.textfield.TextInputEditText
    private lateinit var sshUser: com.google.android.material.textfield.TextInputEditText
    private lateinit var sshPass: com.google.android.material.textfield.TextInputEditText
    private lateinit var sshKey: com.google.android.material.textfield.TextInputEditText
    private lateinit var sshKeyPass: com.google.android.material.textfield.TextInputEditText
    private lateinit var sshHostKey: com.google.android.material.textfield.TextInputEditText
    private lateinit var localSocks: com.google.android.material.textfield.TextInputEditText
    private lateinit var localSocksUser: com.google.android.material.textfield.TextInputEditText
    private lateinit var localSocksPass: com.google.android.material.textfield.TextInputEditText
    private lateinit var localHttp: com.google.android.material.textfield.TextInputEditText
    private lateinit var localForward: com.google.android.material.textfield.TextInputEditText
    private lateinit var pollMin: com.google.android.material.textfield.TextInputEditText
    private lateinit var pollMax: com.google.android.material.textfield.TextInputEditText
    private lateinit var kcpWindow: com.google.android.material.textfield.TextInputEditText
    private lateinit var kcpInterval: com.google.android.material.textfield.TextInputEditText
    private lateinit var kcpResend: com.google.android.material.textfield.TextInputEditText
    private lateinit var smuxBuf: com.google.android.material.textfield.TextInputEditText
    private lateinit var idle: com.google.android.material.textfield.TextInputEditText
    private lateinit var keepAlive: com.google.android.material.textfield.TextInputEditText
    private lateinit var reconnect: com.google.android.material.textfield.TextInputEditText

    private lateinit var transport: () -> String
    private lateinit var mode: () -> String
    private lateinit var fragEnabled: com.google.android.material.materialswitch.MaterialSwitch
    private lateinit var socksFast: com.google.android.material.materialswitch.MaterialSwitch
    private lateinit var kcpNoDelay: com.google.android.material.materialswitch.MaterialSwitch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val given = intent.getStringExtra("profile")
        p = if (given != null) Profiles.normalize(JSONObject(given)) else Profiles.defaults()
        setContentView(R.layout.activity_simple)
        val tb = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        tb.title = if (given != null) getString(R.string.edit) else getString(R.string.add_profile)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }

        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 0, 32, 64)
        }
        val scroll = NestedScrollView(this).apply { addView(container) }
        findViewById<android.widget.FrameLayout>(R.id.content).addView(scroll)
        build()
    }

    private fun build() {
        f.section(R.string.sec_general)
        name = f.text(R.string.f_name, p.optString("name"))

        f.section(R.string.sec_server)
        domain = f.text(R.string.f_domain, p.optString("domain"), R.string.f_domain_h)
        pubkey = f.text(R.string.f_pubkey, p.optString("pubkey"), R.string.f_pubkey_h, multiline = true)
        val segNote = f.note("")
        domain.addTextChangedListener(afterChange { updateSegmentNote(segNote) })
        updateSegmentNote(segNote)

        f.section(R.string.sec_transport)
        transport = f.dropdown(
            R.string.f_transport,
            listOf(getString(R.string.o_doh), getString(R.string.o_dot), getString(R.string.o_udp)),
            listOf("doh", "dot", "udp"), p.optString("transport").takeIf { it in listOf("doh", "dot", "udp") } ?: "udp"
        )
        val rs = p.optJSONArray("resolvers") ?: JSONArray()
        resolvers = f.text(
            R.string.f_resolvers,
            (0 until rs.length()).mapNotNull { rs.optString(it, "").takeIf(String::isNotBlank) }.joinToString("\n").ifEmpty { "8.8.8.8:53" },
            R.string.f_resolvers_h
        )
        f.section(R.string.sec_dns)
        remoteDns = f.text(R.string.f_remote_dns, p.optString("remoteDns", "8.8.8.8:53"), R.string.f_remote_dns_h)
        utls = f.text(R.string.f_utls, p.optString("utls"), R.string.f_utls_h)
        f.note(Ghostcore.fingerprints().replace(",", ", "))
        dohSenders = f.text(R.string.f_doh_senders, p.optInt("dohSenders").toString(), number = true)

        f.section(R.string.sec_segments)
        segment = f.text(R.string.f_segment, p.optInt("segmentSize").toString(), R.string.f_segment_h, number = true)
        val frag = p.optJSONObject("fragment") ?: JSONObject()
        fragEnabled = f.switch(R.string.f_frag, frag.optBoolean("enabled"))
        fragMin = f.text(R.string.f_frag_min, frag.optInt("minSize", 1).toString(), number = true)
        fragMax = f.text(R.string.f_frag_max, frag.optInt("maxSize", 5).toString(), number = true)
        fragDelay = f.text(R.string.f_frag_delay, frag.optInt("delayMs", 5).toString(), number = true)
        fragPackets = f.text(R.string.f_frag_packets, frag.optInt("packets", 1).toString(), number = true)

        f.section(R.string.sec_mode)
        mode = f.dropdown(
            R.string.f_mode,
            listOf(getString(R.string.o_socks), getString(R.string.o_ssh), getString(R.string.o_forward)),
            listOf("socks", "ssh", "forward"), p.optString("mode")
        )

        f.section(R.string.sec_socks)
        socksUser = f.text(R.string.f_socks_user, p.optString("socksUser"))
        socksPass = f.text(R.string.f_socks_pass, p.optString("socksPass"), password = true)
        socksFast = f.switch(R.string.f_socks_fast, p.optBoolean("socksFast", true))

        f.section(R.string.sec_ssh)
        sshUser = f.text(R.string.f_ssh_user, p.optString("sshUser"))
        sshPass = f.text(R.string.f_ssh_pass, p.optString("sshPass"), password = true)
        sshKey = f.text(R.string.f_ssh_key, p.optString("sshKey"), multiline = true)
        sshKeyPass = f.text(R.string.f_ssh_key_pass, p.optString("sshKeyPass"), password = true)
        sshHostKey = f.text(R.string.f_ssh_hostkey, p.optString("sshHostKey"))

        f.section(R.string.sec_local)
        localSocks = f.text(R.string.f_local_socks, p.optString("localSocks"))
        localSocksUser = f.text(R.string.f_local_socks_user, p.optString("localSocksUser"))
        localSocksPass = f.text(R.string.f_local_socks_pass, p.optString("localSocksPass"), password = true)
        localHttp = f.text(R.string.f_local_http, p.optString("localHttp"))
        localForward = f.text(R.string.f_local_forward, p.optString("localForward"))

        f.section(R.string.sec_advanced)
        f.note(getString(R.string.kcp_2021_hint))
        pollMin = f.text(R.string.f_poll_min, p.optInt("pollMinMs", 500).toString(), number = true)
        pollMax = f.text(R.string.f_poll_max, p.optInt("pollMaxMs", 10000).toString(), number = true)
        kcpNoDelay = f.switch(R.string.f_kcp_nodelay, p.optBoolean("kcpNoDelay", false))
        kcpInterval = f.text(R.string.f_kcp_interval, p.optInt("kcpIntervalMs", 0).toString(), number = true)
        kcpResend = f.text(R.string.f_kcp_resend, p.optInt("kcpResend", 0).toString(), number = true)
        kcpWindow = f.text(R.string.f_kcp_window, p.optInt("kcpWindow", 0).toString(), number = true)
        smuxBuf = f.text(R.string.f_smux_buf, p.optInt("smuxBufferKB", 1024).toString(), number = true)
        idle = f.text(R.string.f_idle, p.optInt("idleTimeoutSec", 120).toString(), number = true)
        keepAlive = f.text(R.string.f_keepalive, p.optInt("keepAliveSec", 10).toString(), number = true)
        reconnect = f.text(R.string.f_reconnect, p.optInt("reconnectSec", 3).toString(), number = true)
        f.add(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.kcp_defaults_button)
            setOnClickListener {
                pollMin.setText("500")
                pollMax.setText("10000")
                kcpNoDelay.isChecked = false
                kcpInterval.setText("0")
                kcpResend.setText("0")
                kcpWindow.setText("0")
                smuxBuf.setText("1024")
                idle.setText("120")
                keepAlive.setText("10")
                reconnect.setText("3")
                // This action explicitly restores stock behavior, including the global force-turbo switch.
                AppSettings.edit(this@ProfileEditActivity).putBoolean("tcp_no_delay", false).apply()
                toast(getString(R.string.kcp_defaults_applied))
            }
        })
        f.add(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.max_speed_preset)
            setOnClickListener {
                kcpNoDelay.isChecked = true
                kcpInterval.setText("10")
                kcpResend.setText("2")
                // dnstt's packet queues are 128 packets; avoid a much larger KCP window on mobile.
                kcpWindow.setText("128")
                smuxBuf.setText("4096")
                pollMin.setText("100")
                pollMax.setText("3000")
                fragEnabled.isChecked = false
                toast(getString(R.string.max_speed_applied))
            }
        })
    }

    private fun updateSegmentNote(tv: android.widget.TextView) {
        val max = Ghostcore.maxSegmentSize(domain.str())
        tv.text = if (max > 0) getString(R.string.max_segment, max) else ""
    }

    private fun afterChange(fn: () -> Unit) = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: android.text.Editable?) = fn()
    }

    private fun collect(): JSONObject {
        val out = JSONObject(p.toString())
        out.put("name", name.str())
        out.put("domain", domain.str())
        out.put("pubkey", pubkey.str())
        out.put("transport", transport())
        val resolverValues = resolvers.str().split(',', ' ', '\n').map { it.trim() }.filter { it.isNotBlank() }
        out.put("resolvers", JSONArray(resolverValues))
        out.put("resolverStrategy", "roundrobin")
        out.put("remoteDns", remoteDns.str().trim())
        out.put("utls", utls.str().ifEmpty { "Chrome_120" })
        out.put("dohSenders", dohSenders.int(32))
        out.put("segmentSize", segment.int(0))
        out.put("fragment", JSONObject().apply {
            put("enabled", fragEnabled.isChecked)
            put("minSize", fragMin.int(1))
            put("maxSize", fragMax.int(5))
            put("delayMs", fragDelay.int(5))
            put("packets", fragPackets.int(1))
        })
        out.put("mode", mode())
        out.put("socksUser", socksUser.str())
        out.put("socksPass", socksPass.str())
        out.put("socksFast", socksFast.isChecked)
        out.put("sshUser", sshUser.str())
        out.put("sshPass", sshPass.str())
        out.put("sshKey", sshKey.text?.toString() ?: "")
        out.put("sshKeyPass", sshKeyPass.str())
        out.put("sshHostKey", sshHostKey.str())
        out.put("localSocks", localSocks.str())
        out.put("localSocksUser", localSocksUser.str())
        out.put("localSocksPass", localSocksPass.str())
        out.put("localHttp", localHttp.str())
        out.put("localForward", localForward.str())
        out.put("pollMinMs", pollMin.int(500).coerceIn(100, 5000))
        out.put("pollMaxMs", pollMax.int(10000).coerceIn(1000, 60000))
        out.put("kcpNoDelay", kcpNoDelay.isChecked)
        out.put("kcpIntervalMs", kcpInterval.int(0).coerceIn(0, 5000))
        out.put("kcpResend", kcpResend.int(0).coerceIn(0, 16))
        out.put("kcpWindow", kcpWindow.int(0).coerceIn(0, 1024))
        out.put("smuxBufferKB", smuxBuf.int(1024).coerceIn(256, 131072))
        out.put("idleTimeoutSec", idle.int(120).coerceIn(1, 3600))
        out.put("keepAliveSec", keepAlive.int(10).coerceIn(1, 3600))
        out.put("reconnectSec", reconnect.int(3).coerceIn(1, 3600))
        return out
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.edit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.e_save) {
            val out = collect()
            val err = Ghostcore.checkConfig(out.toString())
            if (err.isNotEmpty()) {
                toast(getString(R.string.profile_invalid, err))
                return true
            }
            Profiles.save(this, out)
            setResult(RESULT_OK)
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
