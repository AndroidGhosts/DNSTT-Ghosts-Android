#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java/JDK is missing. Install JDK 17 in AndroidIDE first." >&2
  exit 2
fi
java -version 2>&1 | head -n 1
chmod +x ./gradlew
./gradlew --no-daemon --stacktrace verifyGhostcoreArm64 assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "ERROR: Expected single APK was not generated: $APK" >&2
  find app/build/outputs/apk -type f -maxdepth 4 -print 2>/dev/null || true
  exit 3
fi
mkdir -p dist
cp "$APK" dist/DNSTT-Ghosts-arm64-v8a-debug.apk
printf '
ARM64 APK created:
'
ls -lh dist/DNSTT-Ghosts-arm64-v8a-debug.apk
if command -v aapt >/dev/null 2>&1; then
  aapt dump badging dist/DNSTT-Ghosts-arm64-v8a-debug.apk | grep -E "^(package:|native-code:)" || true
fi
