# تقرير تحديث DNSTT Ghosts 1.4.8-arm64

## ما تغير
- تحديث رقم الإصدار إلى `1.4.8-arm64` ورقم البناء إلى `12`.
- قصر تغليف المكتبات الأصلية على `arm64-v8a` فقط وإزالة إعدادات APK الشامل وتقسيمات ABI المتعددة.
- إضافة مهمة Gradle باسم `verifyGhostcoreArm64` تتحقق من وجود `jni/arm64-v8a/libgojni.so` داخل `app/libs/ghostcore.aar` قبل `preBuild`.
- تحسين التباعد، زوايا البطاقات، حدودها، حجم زر الاتصال ومساحة الرسم في الشاشة الرئيسية.
- إضافة رابط مباشر إلى قناة Telegram داخل الشاشة الرئيسية، مع نصوص إنجليزية وعربية.
- تحديث `build-debug-apk.sh` لنسخ الناتج إلى `dist/DNSTT-Ghosts-arm64-v8a-debug.apk`.
- تحديث تعليمات البناء وسير عمل GitHub Actions لرفع APK فقط كـ Artifact باسم `DNSTT-Ghosts-arm64-v8a-APK`.

## تحقق محلي
- تم تحليل 22 ملف XML بنجاح.
- تم التأكد من أن `ghostcore.aar` يحتوي على `jni/arm64-v8a/libgojni.so` بحجم 13,627,936 بايت.
- يحتوي AAR أيضًا على ABI أخرى، لكن إعداد Gradle الجديد يستهدف `arm64-v8a` فقط.
- لم يكتمل بناء APK داخل بيئة العمل لأن تنزيل Gradle من `services.gradle.org` فشل بسبب `UnknownHostException`. لذلك لا يُدّعى أن APK قد بُني أو اختُبر هنا.

## الخطوة التالية
ارفع هذا الملف إلى مستودع GitHub باسم يتضمن `arm64-source.zip` حتى يختاره سير العمل الجديد، ثم افتح Actions وشغّل `Build DNSTT Ghosts ARM64 APK`. سيكون Artifact الناتج ZIP تنزيلًا من GitHub يحتوي على ملف APK فقط؛ بعد فك ضغط الـ Artifact تحصل على ملف APK مستقل.
