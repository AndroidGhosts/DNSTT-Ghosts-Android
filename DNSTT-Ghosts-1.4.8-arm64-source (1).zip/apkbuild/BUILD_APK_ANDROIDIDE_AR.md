# بناء DNSTT Ghosts إلى APK على AndroidIDE

> هذه حزمة مصدر وليست APK. لم أتمكن من التجميع داخل بيئة العمل الحالية لأن اتصالها بمستودعات Gradle وAndroid محجوب. إعدادات Gradle هنا محدثة لتوافق API 36، لكن يجب نجاح بناء فعلي على جهاز متصل بالإنترنت قبل اعتبار التطبيق مختبَرًا.

## 1) فك الضغط وفتح المشروع

1. فكّ ملف ZIP في مجلد محلي على الهاتف.
2. افتح AndroidIDE واختر **Open existing project**.
3. حدّد مجلد `dnstt-ghosts` الذي يحتوي `settings.gradle.kts` و`gradlew`، وليس مجلد `app` وحده.
4. استخدم JDK 17 أو أحدث، واترك Gradle يُنزّل التوزيعة والاعتماديات أول مرة.

## 2) متطلبات SDK

المشروع مضبوط على `compileSdk = 36` ويستخدم Android Gradle Plugin `8.9.1` وGradle `8.11.1`. يجب تثبيت Android SDK Platform 36 وBuild Tools المناسبة من SDK Manager/طرفية AndroidIDE. الإعداد الأولي في AndroidIDE يكون عادةً عبر:

```bash
idesetup -c -j 17
```

إذا كان `sdkmanager` متاحًا في الطرفية، ثبّت المنصة والأدوات المطلوبة:

```bash
sdkmanager "platforms;android-36" "build-tools;36.0.0" "platform-tools"
```

إذا لم يتعرّف AndroidIDE على `sdkmanager` أو تعذّر تنزيل API 36، فلا تغيّر إصدارات Gradle عشوائيًا؛ أرسل سجل الخطأ كاملًا.

## 3) بناء APK التجريبي

من طرفية AndroidIDE، انتقل إلى مجلد المشروع وشغّل:

```bash
chmod +x gradlew build-debug-apk.sh
./build-debug-apk.sh
```

أو نفّذ أمر Gradle مباشرة:

```bash
./gradlew --no-daemon --stacktrace assembleDebug
```

بعد نجاح البناء ستجد APK في:

```text
app/build/outputs/apk/debug/
```

بسبب إعداد تقسيم ABI قد تظهر عدة ملفات APK، مع APK شامل إذا نجح توليده.

## 4) ملاحظات

- ابدأ بـ `assembleDebug` للاختبار؛ لا تستخدم `assembleRelease` دون إعداد مفتاح توقيع خاص بك.
- أول بناء يحتاج إنترنت لتنزيل Gradle واعتماديات Maven، وقد يحتاج مساحة حرة إضافية.
- نجاح البناء لا يثبت وحده أن اتصال DNSTT أو VPN يعمل؛ اختبر التطبيق على جهازك وبعد التثبيت.
- لا ترسل أي ملف `keystore.properties` أو مفتاح توقيع خاص.
